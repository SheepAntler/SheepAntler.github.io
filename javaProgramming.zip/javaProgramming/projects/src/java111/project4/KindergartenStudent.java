/** The KindergartenStudent class extends the Student class. It will
 *  add an instance variable specific to KindergartenStudent objects
 *  and override the Student class's toString() method with its own
 *  String representation of a KindergartenStudent.
 *
 *  @author Elspeth Stalter-Clouse
 */
public class KindergartenStudent extends Student {
    // add a show-and-tell item instance variable
    private String showAndTellItem;

    // get-and-set!
	/**
	* Returns value of showAndTellItem
	* @return showAndTellItem
	*/
	public String getShowAndTellItem() {
		return showAndTellItem;
	}

	/**
	* Sets new value of showAndTellItem
	* @param showAndTellItem
	*/
	public void setShowAndTellItem(String showAndTellItem) {
		this.showAndTellItem = showAndTellItem;
	}

    /** This method overrides the toString() method in the Student class.
     *  It will return a String representation of a Kindergarten Student object.
     *  @return String description of a KindergartenStudent
     */
    public String toString() {
        return super.toString() + " " + getStudentFirstName() + " is in "
                + "kindergarten and will be bringing " + showAndTellItem
                + " to Show-And-Tell this week.";
    }

}
