/** The HighSchoolStudent is a subclass of the GeneralStudent class
 *  which implements the TestTaker interface. It will contain some
 *  HighSchoolStudent-specific instance variables along with
 *  some methods required to override the displayProgress() method in
 *  the GeneralStudent superclass.
 *
 *  @author Elspeth Stalter-Clouse
 */
public class HighSchoolStudent extends GeneralStudent implements TestTaker {
    // HighSchoolStudent-specific instance variables
    private String driverStatus;
    private String futurePlans;
    private int collegeEntryExamScore;

    // get-and-set

    /**
	* Returns value of driverStatus
	* @return driverStatus
	*/
	public String getDriverStatus() {
		return driverStatus;
	}

	/**
	* Sets new value of driverStatus
	* @param driverStatus
	*/
	public void setDriverStatus(String driverStatus) {
		this.driverStatus = driverStatus;
	}
	/**
	* Returns value of futurePlans
	* @return futurePlans
	*/
	public String getFuturePlans() {
		return futurePlans;
	}

	/**
	* Sets new value of futurePlans
	* @param futurePlans
	*/
	public void setFuturePlans(String futurePlans) {
		this.futurePlans = futurePlans;
	}

	/**
	* Returns value of collegeEntryExamScore
	* @return collegeEntryExamScore
	*/
	public int getCollegeEntryExamScore() {
		return collegeEntryExamScore;
	}

	/**
	* Sets new value of collegeEntryExamScore
	* @param collegeEntryExamScore
	*/
	public void setCollegeEntryExamScore(int collegeEntryExamScore) {
		this.collegeEntryExamScore = collegeEntryExamScore;
	}

    /** The displayProgress() method will override the method in the
     *  GeneralStudent superclass and output a progress report for an
     *  MiddleSchoolStudent object
     *  @return the progressReport string
     */
    public String displayProgress() {

        return getFirstName() + " "
                + getLastName() + " is a(n) " + getGrade() + "th grader at "
                + getSchool() + ". " + getFirstName() + " is adept in "
                + getStrongestSubject() + ", but they could use some extra "
                + "practice in " + getWeakestSubject() + ". "
                + getFirstName() + " " + getDriverStatus() + ", "
                + "and when they graduate they hope to "
                + getFuturePlans() + ".";
    }

    /** The takeTest() method will describe the test the student is taking.
     */
    public void takeTest() {
        System.out.println(System.lineSeparator() + getFirstName() + " "
                + getLastName() + " is taking the SAT exam...");
    }

    /** The getTestResults() method will output the student's test time and
     *  test score
     *  @return String representing the student's results
     */
    public String getTestResults() {
        // A local variable to hold the testResults String
        String testResults = "";

        if (getCollegeEntryExamScore() >= 1200) {
            testResults = getFirstName() + " " + getLastName()
                    + " completed the test in " + getTestCompletionTime()
                    + ". Their overall score is " + getCollegeEntryExamScore()
                    + ". This is a high score. " + getFirstName()
                    + " scored highest in " + getStrongestSubject()
                    + " and lowest in " + getWeakestSubject() + ".";
        } else if (getCollegeEntryExamScore() >= 1068 &&
                getCollegeEntryExamScore() < 1200) {
            testResults = getFirstName() + " " + getLastName()
                    + " completed the test in " + getTestCompletionTime()
                    + ". Their overall score is " + getCollegeEntryExamScore()
                    + ". This is an average score. " + getFirstName()
                    + " scored highest in " + getStrongestSubject()
                    + " and lowest in " + getWeakestSubject() + ".";
        } else if (getCollegeEntryExamScore() < 1068) {
            testResults = getFirstName() + " " + getLastName()
                    + " completed the test in " + getTestCompletionTime()
                    + ". Their overall score is " + getCollegeEntryExamScore()
                    + ". This is a relatively low score. " + getFirstName()
                    + " scored highest in " + getStrongestSubject()
                    + " and lowest in " + getWeakestSubject() + ".";
        }

        // return the appropriate String to the caller
        return testResults;
    }
}
