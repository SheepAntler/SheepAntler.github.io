/** The MiddleSchoolStudent is a subclass of the GeneralStudent class
 *  which implements the TestTaker interface. It will contain some
 *  MiddleSchoolStudent-specific instance variables along with
 *  some methods required to override the displayProgress() method in
 *  the GeneralStudent superclass.
 *
 *  @author Elspeth Stalter-Clouse
 */
public class MiddleSchoolStudent extends GeneralStudent implements TestTaker {
    // MiddleSchoolStudent-specific instance variables
    private int awkwardnessLevel;
    private int popularity;
    private int preparatoryTestScore;

    // get-and-set!

	/**
	* Returns value of awkwardnessLevel
	* @return awkwardnessLevel
	*/
	public int getAwkwardnessLevel() {
		return awkwardnessLevel;
	}

	/**
	* Sets new value of awkwardnessLevel
	* @param awkwardnessLevel
	*/
	public void setAwkwardnessLevel(int awkwardnessLevel) {
		this.awkwardnessLevel = awkwardnessLevel;
	}

	/**
	* Returns value of popularity
	* @return popularity
	*/
	public int getPopularity() {
		return popularity;
	}

	/**
	* Sets new value of popularity
	* @param popularity
	*/
	public void setPopularity(int popularity) {
		this.popularity = popularity;
	}

	/**
	* Returns value of preparatoryTestScore
	* @return preparatoryTestScore
	*/
	public int getPreparatoryTestScore() {
		return preparatoryTestScore;
	}

	/**
	* Sets new value of preparatoryTestScore
	* @param preparatoryTestScore
	*/
	public void setPreparatoryTestScore(int preparatoryTestScore) {
		this.preparatoryTestScore = preparatoryTestScore;
	}

    /** The displayProgress() method will override the method in the
     *  GeneralStudent superclass and output a progress report for an
     *  MiddleSchoolStudent object
     *  @return the progressReport string
     */
    public String displayProgress() {
        // A local variable to hold the progressReport string
        String progressReport = "";
        if (getAwkwardnessLevel() >= 7) {
            progressReport = getFirstName() + " "
                    + getLastName() + " is a " + getGrade() + "th grader at "
                    + getSchool() + ". " + getFirstName() + " is adept in "
                    + getStrongestSubject() + ", but they could use some extra "
                    + "practice in " + getWeakestSubject() + ". "
                    + getFirstName() + "\'s awkwardness level is "
                    + getAwkwardnessLevel() + ", which is quite high. This level "
                    + "of awkwardness is keeping their popularity score down at a "
                    + getPopularity() + ".";
        } else if (getAwkwardnessLevel() >= 4 && getAwkwardnessLevel() < 7) {
            progressReport = getFirstName() + " "
                    + getLastName() + " is a " + getGrade() + "th grader at "
                    + getSchool() + ". " + getFirstName() + " is adept in "
                    + getStrongestSubject() + ", but they could use some extra "
                    + "practice in " + getWeakestSubject() + ". "
                    + getFirstName() + "\'s awkwardness level is "
                    + getAwkwardnessLevel() + ", which is pretty average. "
                    + "This level of awkwardness is keeping their popularity "
                    + "score at an even " + getPopularity() + ".";
        } else if (getAwkwardnessLevel() < 4) {
            progressReport = getFirstName() + " "
                    + getLastName() + " is a " + getGrade() + "th grader at "
                    + getSchool() + ". " + getFirstName() + " is adept in "
                    + getStrongestSubject() + ", but they could use some extra "
                    + "practice in " + getWeakestSubject() + ". "
                    + getFirstName() + "\'s awkwardness level is "
                    + getAwkwardnessLevel() + ", which is remarkably low. "
                    + "This level of awkwardness is keeping their popularity "
                    + "score up around " + getPopularity() + ".";
        }

        return progressReport;
    }

    /** The takeTest() method will describe the test the student is taking.
     */
    public void takeTest() {
        System.out.println(System.lineSeparator() + getFirstName() + " "
                + getLastName() + " is taking a pre-SAT exam...");
    }

    /** The getTestResults() method will output the student's test time and
     *  test score
     *  @return String representing the student's results
     */
    public String getTestResults() {
        // A local variable to hold the testResults String
        String testResults = "";

        if (getPreparatoryTestScore() >= 1200) {
            testResults = getFirstName() + " " + getLastName()
                    + " completed the test in " + getTestCompletionTime()
                    + ". Their overall score is " + getPreparatoryTestScore()
                    + ". This is a high score. " + getFirstName()
                    + " scored highest in " + getStrongestSubject()
                    + " and lowest in " + getWeakestSubject() + ".";
        } else if (getPreparatoryTestScore() >= 1068 &&
                getPreparatoryTestScore() < 1200) {
            testResults = getFirstName() + " " + getLastName()
                    + " completed the test in " + getTestCompletionTime()
                    + ". Their overall score is " + getPreparatoryTestScore()
                    + ". This is an average score. " + getFirstName()
                    + " scored highest in " + getStrongestSubject()
                    + " and lowest in " + getWeakestSubject() + ".";
        } else if (getPreparatoryTestScore() < 1068) {
            testResults = getFirstName() + " " + getLastName()
                    + " completed the test in " + getTestCompletionTime()
                    + ". Their overall score is " + getPreparatoryTestScore()
                    + ". This is a relatively low score. " + getFirstName()
                    + " scored highest in " + getStrongestSubject()
                    + " and lowest in " + getWeakestSubject() + ".";
        }

        // return the appropriate String to the caller
        return testResults;
    }
}
