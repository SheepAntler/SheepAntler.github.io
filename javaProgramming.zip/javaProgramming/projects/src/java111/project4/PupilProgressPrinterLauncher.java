/** This class contains the main method for the PupilProgressPrinter
 *  applictaion. It will instantiate a new BuildStudentProgressReports object
 *  and call its run() method.
 *  @author Elspeth Stalter-Clouse
 */
public class PupilProgressPrinterLauncher {
    /** Here is the MAIN METHOD!
     *  @param args
     */
    public static void main(String[] args) {
        // instantiate a new BuildStudentProgressReports object
        BuildStudentProgressReports printReports = new BuildStudentProgressReports();

        // call its run method
        printReports.run();
    }
}
