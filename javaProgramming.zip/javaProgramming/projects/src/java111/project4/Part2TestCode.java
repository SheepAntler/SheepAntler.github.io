/** This is the test code for Part 2 of Project 4. It will contain a main method
 *  that instantiates an object from each of the GeneralStudent class's
 *  three subclasses, sets some sample data for each, and outputs
 *  SUCCESS/FAILURE messages based on whether the resulting output is
 *  the expected output or not. This class will verify that each if/else
 *  in each GeneralStudent subclass runs correctly.
 *
 *  @author Elspeth Stalter-Clouse
 */
public class Part2TestCode {
    /** Here is the main method
     *  @param args command line arguments
     */
    public static void main(String[] args) {

        // TEST CYCLE 1: ELEMENTARY SCHOOL STUDENTS

        // PART 1: Test each if/else branch in the Elementary School Student's
        // displayProgress() method

        // k
        ElementarySchoolStudent elementaryStudent = new ElementarySchoolStudent();

        // create some test variables
        String firstName = "Samwise";
        String lastName = "Gamgee";
        String school = "Hobbit School";
        String grade = "k";
        String strongestSubject = "counting";
        String weakestSubject = "spelling";
        String testCompletionTime = "2 hours";
        String favoriteRecessActivity = "swing";
        String snackPack = "goldfish crackers";
        int standardizedTestScore = 350;

        // set this data into the ElementarySchoolStudent object
        elementaryStudent.setFirstName(firstName);
        elementaryStudent.setLastName(lastName);
        elementaryStudent.setSchool(school);
        elementaryStudent.setGrade(grade);
        elementaryStudent.setStrongestSubject(strongestSubject);
        elementaryStudent.setWeakestSubject(weakestSubject);
        elementaryStudent.setTestCompletionTime(testCompletionTime);
        elementaryStudent.setFavoriteRecessActivity(favoriteRecessActivity);
        elementaryStudent.setSnackPack(snackPack);
        elementaryStudent.setStandardizedTestScore(standardizedTestScore);

        // create a String to hold the expected output
        String expectedOutput = firstName + " "
                + lastName + " is a kindergartener at " + school
                + ". " + firstName + " is adept in "
                + strongestSubject + ", but they could use some extra "
                + "practice in " + weakestSubject + ". During recess, "
                + firstName + " loves to " + favoriteRecessActivity
                + ", and their favorite snack is " + snackPack + ".";

        // create a String to hold the actual output
        String actualOutput = elementaryStudent.displayProgress();

        // compare the results and output SUCCESS/FAILURE
        System.out.println();
        System.out.println("Testing ElementarySchoolStudent displayProgress(), k...");
        System.out.println();

        if (expectedOutput.equals(actualOutput)) {
            System.out.println("SUCCESS!");
        } else {
            System.out.println("FAILURE. " + expectedOutput + " was expected, "
                    + "but " + actualOutput + " was returned.");
        }

        // 1
        elementaryStudent = new ElementarySchoolStudent();

        // create some test variables
        firstName = "Samwise";
        lastName = "Gamgee";
        school = "Hobbit School";
        grade = "1";
        strongestSubject = "counting";
        weakestSubject = "spelling";
        testCompletionTime = "2 hours";
        favoriteRecessActivity = "swing";
        snackPack = "goldfish crackers";
        standardizedTestScore = 350;

        // set this data into the ElementarySchoolStudent object
        elementaryStudent.setFirstName(firstName);
        elementaryStudent.setLastName(lastName);
        elementaryStudent.setSchool(school);
        elementaryStudent.setGrade(grade);
        elementaryStudent.setStrongestSubject(strongestSubject);
        elementaryStudent.setWeakestSubject(weakestSubject);
        elementaryStudent.setTestCompletionTime(testCompletionTime);
        elementaryStudent.setFavoriteRecessActivity(favoriteRecessActivity);
        elementaryStudent.setSnackPack(snackPack);
        elementaryStudent.setStandardizedTestScore(standardizedTestScore);

        // create a String to hold the expected output
        expectedOutput = firstName + " "
                + lastName + " is a " + grade + "st grader at " + school
                + ". " + firstName + " is adept in "
                + strongestSubject + ", but they could use some extra "
                + "practice in " + weakestSubject + ". During recess, "
                + firstName + " loves to " + favoriteRecessActivity
                + ", and their favorite snack is " + snackPack + ".";

        // create a String to hold the actual output
        actualOutput = elementaryStudent.displayProgress();

        // compare the results and output SUCCESS/FAILURE
        System.out.println();
        System.out.println("Testing ElementarySchoolStudent displayProgress(), 1...");
        System.out.println();

        if (expectedOutput.equals(actualOutput)) {
            System.out.println("SUCCESS!");
        } else {
            System.out.println("FAILURE. " + expectedOutput + " was expected, "
                    + "but " + actualOutput + " was returned.");
        }

        // 2
        elementaryStudent = new ElementarySchoolStudent();

        // create some test variables
        firstName = "Samwise";
        lastName = "Gamgee";
        school = "Hobbit School";
        grade = "2";
        strongestSubject = "counting";
        weakestSubject = "spelling";
        testCompletionTime = "2 hours";
        favoriteRecessActivity = "swing";
        snackPack = "goldfish crackers";
        standardizedTestScore = 350;

        // set this data into the ElementarySchoolStudent object
        elementaryStudent.setFirstName(firstName);
        elementaryStudent.setLastName(lastName);
        elementaryStudent.setSchool(school);
        elementaryStudent.setGrade(grade);
        elementaryStudent.setStrongestSubject(strongestSubject);
        elementaryStudent.setWeakestSubject(weakestSubject);
        elementaryStudent.setTestCompletionTime(testCompletionTime);
        elementaryStudent.setFavoriteRecessActivity(favoriteRecessActivity);
        elementaryStudent.setSnackPack(snackPack);
        elementaryStudent.setStandardizedTestScore(standardizedTestScore);

        // create a String to hold the expected output
        expectedOutput = firstName + " "
                + lastName + " is a " + grade + "nd grader at " + school
                + ". " + firstName + " is adept in "
                + strongestSubject + ", but they could use some extra "
                + "practice in " + weakestSubject + ". During recess, "
                + firstName + " loves to " + favoriteRecessActivity
                + ", and their favorite snack is " + snackPack + ".";

        // create a String to hold the actual output
        actualOutput = elementaryStudent.displayProgress();

        // compare the results and output SUCCESS/FAILURE
        System.out.println();
        System.out.println("Testing ElementarySchoolStudent displayProgress(), 2...");
        System.out.println();

        if (expectedOutput.equals(actualOutput)) {
            System.out.println("SUCCESS!");
        } else {
            System.out.println("FAILURE. " + expectedOutput + " was expected, "
                    + "but " + actualOutput + " was returned.");
        }

        // 3
        elementaryStudent = new ElementarySchoolStudent();

        // create some test variables
        firstName = "Samwise";
        lastName = "Gamgee";
        school = "Hobbit School";
        grade = "3";
        strongestSubject = "counting";
        weakestSubject = "spelling";
        testCompletionTime = "2 hours";
        favoriteRecessActivity = "swing";
        snackPack = "goldfish crackers";
        standardizedTestScore = 350;

        // set this data into the ElementarySchoolStudent object
        elementaryStudent.setFirstName(firstName);
        elementaryStudent.setLastName(lastName);
        elementaryStudent.setSchool(school);
        elementaryStudent.setGrade(grade);
        elementaryStudent.setStrongestSubject(strongestSubject);
        elementaryStudent.setWeakestSubject(weakestSubject);
        elementaryStudent.setTestCompletionTime(testCompletionTime);
        elementaryStudent.setFavoriteRecessActivity(favoriteRecessActivity);
        elementaryStudent.setSnackPack(snackPack);
        elementaryStudent.setStandardizedTestScore(standardizedTestScore);

        // create a String to hold the expected output
        expectedOutput = firstName + " "
                + lastName + " is a " + grade + "rd grader at " + school
                + ". " + firstName + " is adept in "
                + strongestSubject + ", but they could use some extra "
                + "practice in " + weakestSubject + ". During recess, "
                + firstName + " loves to " + favoriteRecessActivity
                + ", and their favorite snack is " + snackPack + ".";

        // create a String to hold the actual output
        actualOutput = elementaryStudent.displayProgress();

        // compare the results and output SUCCESS/FAILURE
        System.out.println();
        System.out.println("Testing ElementarySchoolStudent displayProgress(), 3...");
        System.out.println();

        if (expectedOutput.equals(actualOutput)) {
            System.out.println("SUCCESS!");
        } else {
            System.out.println("FAILURE. " + expectedOutput + " was expected, "
                    + "but " + actualOutput + " was returned.");
        }

        // 4
        elementaryStudent = new ElementarySchoolStudent();

        // create some test variables
        firstName = "Samwise";
        lastName = "Gamgee";
        school = "Hobbit School";
        grade = "4";
        strongestSubject = "counting";
        weakestSubject = "spelling";
        testCompletionTime = "2 hours";
        favoriteRecessActivity = "swing";
        snackPack = "goldfish crackers";
        standardizedTestScore = 350;

        // set this data into the ElementarySchoolStudent object
        elementaryStudent.setFirstName(firstName);
        elementaryStudent.setLastName(lastName);
        elementaryStudent.setSchool(school);
        elementaryStudent.setGrade(grade);
        elementaryStudent.setStrongestSubject(strongestSubject);
        elementaryStudent.setWeakestSubject(weakestSubject);
        elementaryStudent.setTestCompletionTime(testCompletionTime);
        elementaryStudent.setFavoriteRecessActivity(favoriteRecessActivity);
        elementaryStudent.setSnackPack(snackPack);
        elementaryStudent.setStandardizedTestScore(standardizedTestScore);

        // create a String to hold the expected output
        expectedOutput = firstName + " "
                + lastName + " is a " + grade + "th grader at " + school
                + ". " + firstName + " is adept in "
                + strongestSubject + ", but they could use some extra "
                + "practice in " + weakestSubject + ". During recess, "
                + firstName + " loves to " + favoriteRecessActivity
                + ", and their favorite snack is " + snackPack + ".";

        // create a String to hold the actual output
        actualOutput = elementaryStudent.displayProgress();

        // compare the results and output SUCCESS/FAILURE
        System.out.println();
        System.out.println("Testing ElementarySchoolStudent displayProgress(), 4...");
        System.out.println();

        if (expectedOutput.equals(actualOutput)) {
            System.out.println("SUCCESS!");
        } else {
            System.out.println("FAILURE. " + expectedOutput + " was expected, "
                    + "but " + actualOutput + " was returned.");
        }

        // 5
        elementaryStudent = new ElementarySchoolStudent();

        // create some test variables
        firstName = "Samwise";
        lastName = "Gamgee";
        school = "Hobbit School";
        grade = "5";
        strongestSubject = "counting";
        weakestSubject = "spelling";
        testCompletionTime = "2 hours";
        favoriteRecessActivity = "swing";
        snackPack = "goldfish crackers";
        standardizedTestScore = 350;

        // set this data into the ElementarySchoolStudent object
        elementaryStudent.setFirstName(firstName);
        elementaryStudent.setLastName(lastName);
        elementaryStudent.setSchool(school);
        elementaryStudent.setGrade(grade);
        elementaryStudent.setStrongestSubject(strongestSubject);
        elementaryStudent.setWeakestSubject(weakestSubject);
        elementaryStudent.setTestCompletionTime(testCompletionTime);
        elementaryStudent.setFavoriteRecessActivity(favoriteRecessActivity);
        elementaryStudent.setSnackPack(snackPack);
        elementaryStudent.setStandardizedTestScore(standardizedTestScore);

        // create a String to hold the expected output
        expectedOutput = firstName + " "
                + lastName + " is a " + grade + "th grader at " + school
                + ". " + firstName + " is adept in "
                + strongestSubject + ", but they could use some extra "
                + "practice in " + weakestSubject + ". During recess, "
                + firstName + " loves to " + favoriteRecessActivity
                + ", and their favorite snack is " + snackPack + ".";

        // create a String to hold the actual output
        actualOutput = elementaryStudent.displayProgress();

        // compare the results and output SUCCESS/FAILURE
        System.out.println();
        System.out.println("Testing ElementarySchoolStudent displayProgress(), 5...");
        System.out.println();

        if (expectedOutput.equals(actualOutput)) {
            System.out.println("SUCCESS!");
        } else {
            System.out.println("FAILURE. " + expectedOutput + " was expected, "
                    + "but " + actualOutput + " was returned.");
        }

        // 6
        elementaryStudent = new ElementarySchoolStudent();

        // create some test variables
        firstName = "Samwise";
        lastName = "Gamgee";
        school = "Hobbit School";
        grade = "6";
        strongestSubject = "counting";
        weakestSubject = "spelling";
        testCompletionTime = "2 hours";
        favoriteRecessActivity = "swing";
        snackPack = "goldfish crackers";
        standardizedTestScore = 350;

        // set this data into the ElementarySchoolStudent object
        elementaryStudent.setFirstName(firstName);
        elementaryStudent.setLastName(lastName);
        elementaryStudent.setSchool(school);
        elementaryStudent.setGrade(grade);
        elementaryStudent.setStrongestSubject(strongestSubject);
        elementaryStudent.setWeakestSubject(weakestSubject);
        elementaryStudent.setTestCompletionTime(testCompletionTime);
        elementaryStudent.setFavoriteRecessActivity(favoriteRecessActivity);
        elementaryStudent.setSnackPack(snackPack);
        elementaryStudent.setStandardizedTestScore(standardizedTestScore);

        // create a String to hold the expected output
        expectedOutput = firstName + " "
                + lastName + " is a " + grade + "th grader at " + school
                + ". " + firstName + " is adept in "
                + strongestSubject + ", but they could use some extra "
                + "practice in " + weakestSubject + ". During recess, "
                + firstName + " loves to " + favoriteRecessActivity
                + ", and their favorite snack is " + snackPack + ".";

        // create a String to hold the actual output
        actualOutput = elementaryStudent.displayProgress();

        // compare the results and output SUCCESS/FAILURE
        System.out.println();
        System.out.println("Testing ElementarySchoolStudent displayProgress(), 6...");
        System.out.println();

        if (expectedOutput.equals(actualOutput)) {
            System.out.println("SUCCESS!");
        } else {
            System.out.println("FAILURE. " + expectedOutput + " was expected, "
                    + "but " + actualOutput + " was returned.");
        }

        // PART 2: Test each if/else branch in the ElementarySchoolStudent's
        // getTestResults() method

        // high score
        elementaryStudent = new ElementarySchoolStudent();

        // create some test variables
        firstName = "Samwise";
        lastName = "Gamgee";
        strongestSubject = "counting";
        weakestSubject = "spelling";
        testCompletionTime = "2 hours";
        standardizedTestScore = 400;

        // set this data into the ElementarySchoolStudent object
        elementaryStudent.setFirstName(firstName);
        elementaryStudent.setLastName(lastName);
        elementaryStudent.setStrongestSubject(strongestSubject);
        elementaryStudent.setWeakestSubject(weakestSubject);
        elementaryStudent.setTestCompletionTime(testCompletionTime);
        elementaryStudent.setStandardizedTestScore(standardizedTestScore);

        // create a string to hold the expected output
        expectedOutput = firstName + " " + lastName
                + " completed the test in " + testCompletionTime
                + ". Their overall score is " + standardizedTestScore
                + ". This is a high score. " + firstName
                + " scored highest in " + strongestSubject
                + " and lowest in " + weakestSubject + ".";

        // create a string to hold the actual output
        actualOutput = elementaryStudent.getTestResults();

        // compare the results and output SUCCESS/FAILURE
        System.out.println();
        System.out.println("Testing ElementarySchoolStudent getTestResults(), high score...");
        System.out.println();

        if (expectedOutput.equals(actualOutput)) {
            System.out.println("SUCCESS!");
        } else {
            System.out.println("FAILURE. " + expectedOutput + " was expected, "
                    + "but " + actualOutput + " was returned.");
        }

        // average score
        elementaryStudent = new ElementarySchoolStudent();

        // create some test variables
        firstName = "Samwise";
        lastName = "Gamgee";
        strongestSubject = "counting";
        weakestSubject = "spelling";
        testCompletionTime = "2 hours";
        standardizedTestScore = 350;

        // set this data into the ElementarySchoolStudent object
        elementaryStudent.setFirstName(firstName);
        elementaryStudent.setLastName(lastName);
        elementaryStudent.setStrongestSubject(strongestSubject);
        elementaryStudent.setWeakestSubject(weakestSubject);
        elementaryStudent.setTestCompletionTime(testCompletionTime);
        elementaryStudent.setStandardizedTestScore(standardizedTestScore);

        // create a string to hold the expected output
        expectedOutput = firstName + " " + lastName
                + " completed the test in " + testCompletionTime
                + ". Their overall score is " + standardizedTestScore
                + ". This is an average score. " + firstName
                + " scored highest in " + strongestSubject
                + " and lowest in " + weakestSubject + ".";

        // create a string to hold the actual output
        actualOutput = elementaryStudent.getTestResults();

        // compare the results and output SUCCESS/FAILURE
        System.out.println();
        System.out.println("Testing ElementarySchoolStudent getTestResults(), average score...");
        System.out.println();

        if (expectedOutput.equals(actualOutput)) {
            System.out.println("SUCCESS!");
        } else {
            System.out.println("FAILURE. " + expectedOutput + " was expected, "
                    + "but " + actualOutput + " was returned.");
        }

        // low score
        elementaryStudent = new ElementarySchoolStudent();

        // create some test variables
        firstName = "Samwise";
        lastName = "Gamgee";
        strongestSubject = "counting";
        weakestSubject = "spelling";
        testCompletionTime = "2 hours";
        standardizedTestScore = 220;

        // set this data into the ElementarySchoolStudent object
        elementaryStudent.setFirstName(firstName);
        elementaryStudent.setLastName(lastName);
        elementaryStudent.setStrongestSubject(strongestSubject);
        elementaryStudent.setWeakestSubject(weakestSubject);
        elementaryStudent.setTestCompletionTime(testCompletionTime);
        elementaryStudent.setStandardizedTestScore(standardizedTestScore);

        // create a string to hold the expected output
        expectedOutput = firstName + " " + lastName
                + " completed the test in " + testCompletionTime
                + ". Their overall score is " + standardizedTestScore
                + ". This is a relatively low score. " + firstName
                + " scored highest in " + strongestSubject
                + " and lowest in " + weakestSubject + ".";

        // create a string to hold the actual output
        actualOutput = elementaryStudent.getTestResults();

        // compare the results and output SUCCESS/FAILURE
        System.out.println();
        System.out.println("Testing ElementarySchoolStudent getTestResults(), low score...");
        System.out.println();

        if (expectedOutput.equals(actualOutput)) {
            System.out.println("SUCCESS!");
        } else {
            System.out.println("FAILURE. " + expectedOutput + " was expected, "
                    + "but " + actualOutput + " was returned.");
        }

        // TEST CYCLE 2: MIDDLE SCHOOL STUDENTS

        // PART 1: Test each if/else branch in the Middle School Student's
        // displayProgress() method

        // high awkwardness level
        MiddleSchoolStudent middleSchoolStudent = new MiddleSchoolStudent();

        // create some test variables
        firstName = "Samwise";
        lastName = "Gamgee";
        school = "Hobbit School";
        grade = "8";
        strongestSubject = "counting";
        weakestSubject = "spelling";
        testCompletionTime = "2 hours";
        int awkwardnessLevel = 9;
        int popularity = 2;
        int preparatoryTestScore = 1200;

        // set this data into the ElementarySchoolStudent object
        middleSchoolStudent.setFirstName(firstName);
        middleSchoolStudent.setLastName(lastName);
        middleSchoolStudent.setSchool(school);
        middleSchoolStudent.setGrade(grade);
        middleSchoolStudent.setStrongestSubject(strongestSubject);
        middleSchoolStudent.setWeakestSubject(weakestSubject);
        middleSchoolStudent.setTestCompletionTime(testCompletionTime);
        middleSchoolStudent.setAwkwardnessLevel(awkwardnessLevel);
        middleSchoolStudent.setPopularity(popularity);
        middleSchoolStudent.setPreparatoryTestScore(preparatoryTestScore);

        // create a String to hold the expected output
        expectedOutput = firstName + " "
                + lastName + " is a " + grade + "th grader at "
                + school + ". " + firstName + " is adept in "
                + strongestSubject + ", but they could use some extra "
                + "practice in " + weakestSubject + ". "
                + firstName + "\'s awkwardness level is "
                + awkwardnessLevel + ", which is quite high. This level "
                + "of awkwardness is keeping their popularity score down at a "
                + popularity + ".";

        // create a String to hold the actual output
        actualOutput = middleSchoolStudent.displayProgress();

        // compare the results and output SUCCESS/FAILURE
        System.out.println();
        System.out.println("Testing MiddleSchoolStudent displayProgress(), high awkwardness level...");
        System.out.println();

        if (expectedOutput.equals(actualOutput)) {
            System.out.println("SUCCESS!");
        } else {
            System.out.println("FAILURE. " + expectedOutput + " was expected, "
                    + "but " + actualOutput + " was returned.");
        }

        // average awkwardness level
        middleSchoolStudent = new MiddleSchoolStudent();

        // create some test variables
        firstName = "Samwise";
        lastName = "Gamgee";
        school = "Hobbit School";
        grade = "8";
        strongestSubject = "counting";
        weakestSubject = "spelling";
        testCompletionTime = "2 hours";
        awkwardnessLevel = 5;
        popularity = 4;
        preparatoryTestScore = 1200;

        // set this data into the ElementarySchoolStudent object
        middleSchoolStudent.setFirstName(firstName);
        middleSchoolStudent.setLastName(lastName);
        middleSchoolStudent.setSchool(school);
        middleSchoolStudent.setGrade(grade);
        middleSchoolStudent.setStrongestSubject(strongestSubject);
        middleSchoolStudent.setWeakestSubject(weakestSubject);
        middleSchoolStudent.setTestCompletionTime(testCompletionTime);
        middleSchoolStudent.setAwkwardnessLevel(awkwardnessLevel);
        middleSchoolStudent.setPopularity(popularity);
        middleSchoolStudent.setPreparatoryTestScore(preparatoryTestScore);

        // create a String to hold the expected output
        expectedOutput = firstName + " "
                + lastName + " is a " + grade + "th grader at "
                + school + ". " + firstName + " is adept in "
                + strongestSubject + ", but they could use some extra "
                + "practice in " + weakestSubject + ". "
                + firstName + "\'s awkwardness level is "
                + awkwardnessLevel + ", which is pretty average. This level "
                + "of awkwardness is keeping their popularity score at an even "
                + popularity + ".";

        // create a String to hold the actual output
        actualOutput = middleSchoolStudent.displayProgress();

        // compare the results and output SUCCESS/FAILURE
        System.out.println();
        System.out.println("Testing MiddleSchoolStudent displayProgress(), average awkwardness level...");
        System.out.println();

        if (expectedOutput.equals(actualOutput)) {
            System.out.println("SUCCESS!");
        } else {
            System.out.println("FAILURE. " + expectedOutput + " was expected, "
                    + "but " + actualOutput + " was returned.");
        }

        // low awkwardness level
        middleSchoolStudent = new MiddleSchoolStudent();

        // create some test variables
        firstName = "Samwise";
        lastName = "Gamgee";
        school = "Hobbit School";
        grade = "8";
        strongestSubject = "counting";
        weakestSubject = "spelling";
        testCompletionTime = "2 hours";
        awkwardnessLevel = 2;
        popularity = 8;
        preparatoryTestScore = 1200;

        // set this data into the ElementarySchoolStudent object
        middleSchoolStudent.setFirstName(firstName);
        middleSchoolStudent.setLastName(lastName);
        middleSchoolStudent.setSchool(school);
        middleSchoolStudent.setGrade(grade);
        middleSchoolStudent.setStrongestSubject(strongestSubject);
        middleSchoolStudent.setWeakestSubject(weakestSubject);
        middleSchoolStudent.setTestCompletionTime(testCompletionTime);
        middleSchoolStudent.setAwkwardnessLevel(awkwardnessLevel);
        middleSchoolStudent.setPopularity(popularity);
        middleSchoolStudent.setPreparatoryTestScore(preparatoryTestScore);

        // create a String to hold the expected output
        expectedOutput = firstName + " "
                + lastName + " is a " + grade + "th grader at "
                + school + ". " + firstName + " is adept in "
                + strongestSubject + ", but they could use some extra "
                + "practice in " + weakestSubject + ". "
                + firstName + "\'s awkwardness level is "
                + awkwardnessLevel + ", which is remarkably low. This level "
                + "of awkwardness is keeping their popularity score up around "
                + popularity + ".";

        // create a String to hold the actual output
        actualOutput = middleSchoolStudent.displayProgress();

        // compare the results and output SUCCESS/FAILURE
        System.out.println();
        System.out.println("Testing MiddleSchoolStudent displayProgress(), low awkwardness level...");
        System.out.println();

        if (expectedOutput.equals(actualOutput)) {
            System.out.println("SUCCESS!");
        } else {
            System.out.println("FAILURE. " + expectedOutput + " was expected, "
                    + "but " + actualOutput + " was returned.");
        }

        // PART 2: Test each if/else branch in the ElementarySchoolStudent's
        // getTestResults() method

        // high score
        middleSchoolStudent = new MiddleSchoolStudent();

        // create some test variables
        firstName = "Samwise";
        lastName = "Gamgee";
        strongestSubject = "counting";
        weakestSubject = "spelling";
        testCompletionTime = "2 hours";
        preparatoryTestScore = 1200;

        // set this data into the ElementarySchoolStudent object
        middleSchoolStudent.setFirstName(firstName);
        middleSchoolStudent.setLastName(lastName);
        middleSchoolStudent.setStrongestSubject(strongestSubject);
        middleSchoolStudent.setWeakestSubject(weakestSubject);
        middleSchoolStudent.setTestCompletionTime(testCompletionTime);
        middleSchoolStudent.setPreparatoryTestScore(preparatoryTestScore);

        // create a string to hold the expected output
        expectedOutput = firstName + " " + lastName
                + " completed the test in " + testCompletionTime
                + ". Their overall score is " + preparatoryTestScore
                + ". This is a high score. " + firstName
                + " scored highest in " + strongestSubject
                + " and lowest in " + weakestSubject + ".";

        // create a string to hold the actual output
        actualOutput = middleSchoolStudent.getTestResults();

        // compare the results and output SUCCESS/FAILURE
        System.out.println();
        System.out.println("Testing MiddleSchoolStudent getTestResults(), high score...");
        System.out.println();

        if (expectedOutput.equals(actualOutput)) {
            System.out.println("SUCCESS!");
        } else {
            System.out.println("FAILURE. " + expectedOutput + " was expected, "
                    + "but " + actualOutput + " was returned.");
        }

        // average score
        middleSchoolStudent = new MiddleSchoolStudent();

        // create some test variables
        firstName = "Samwise";
        lastName = "Gamgee";
        strongestSubject = "counting";
        weakestSubject = "spelling";
        testCompletionTime = "2 hours";
        preparatoryTestScore = 1100;

        // set this data into the ElementarySchoolStudent object
        middleSchoolStudent.setFirstName(firstName);
        middleSchoolStudent.setLastName(lastName);
        middleSchoolStudent.setStrongestSubject(strongestSubject);
        middleSchoolStudent.setWeakestSubject(weakestSubject);
        middleSchoolStudent.setTestCompletionTime(testCompletionTime);
        middleSchoolStudent.setPreparatoryTestScore(preparatoryTestScore);

        // create a string to hold the expected output
        expectedOutput = firstName + " " + lastName
                + " completed the test in " + testCompletionTime
                + ". Their overall score is " + preparatoryTestScore
                + ". This is an average score. " + firstName
                + " scored highest in " + strongestSubject
                + " and lowest in " + weakestSubject + ".";

        // create a string to hold the actual output
        actualOutput = middleSchoolStudent.getTestResults();

        // compare the results and output SUCCESS/FAILURE
        System.out.println();
        System.out.println("Testing MiddleSchoolStudent getTestResults(), average score...");
        System.out.println();

        if (expectedOutput.equals(actualOutput)) {
            System.out.println("SUCCESS!");
        } else {
            System.out.println("FAILURE. " + expectedOutput + " was expected, "
                    + "but " + actualOutput + " was returned.");
        }

        // low score
        middleSchoolStudent = new MiddleSchoolStudent();

        // create some test variables
        firstName = "Samwise";
        lastName = "Gamgee";
        strongestSubject = "counting";
        weakestSubject = "spelling";
        testCompletionTime = "2 hours";
        preparatoryTestScore = 980;

        // set this data into the ElementarySchoolStudent object
        middleSchoolStudent.setFirstName(firstName);
        middleSchoolStudent.setLastName(lastName);
        middleSchoolStudent.setStrongestSubject(strongestSubject);
        middleSchoolStudent.setWeakestSubject(weakestSubject);
        middleSchoolStudent.setTestCompletionTime(testCompletionTime);
        middleSchoolStudent.setPreparatoryTestScore(preparatoryTestScore);

        // create a string to hold the expected output
        expectedOutput = firstName + " " + lastName
                + " completed the test in " + testCompletionTime
                + ". Their overall score is " + preparatoryTestScore
                + ". This is a relatively low score. " + firstName
                + " scored highest in " + strongestSubject
                + " and lowest in " + weakestSubject + ".";

        // create a string to hold the actual output
        actualOutput = middleSchoolStudent.getTestResults();

        // compare the results and output SUCCESS/FAILURE
        System.out.println();
        System.out.println("Testing MiddleSchoolStudent getTestResults(), low score...");
        System.out.println();

        if (expectedOutput.equals(actualOutput)) {
            System.out.println("SUCCESS!");
        } else {
            System.out.println("FAILURE. " + expectedOutput + " was expected, "
                    + "but " + actualOutput + " was returned.");
        }

        // TEST CYCLE 3: HIGH SCHOOL STUDENTS

        // PART 1: Test the High School Student's displayProgress() method

        // create and instantiate a HighSchoolStudent object
        HighSchoolStudent highSchoolStudent = new HighSchoolStudent();

        // create some test variables
        firstName = "Samwise";
        lastName = "Gamgee";
        school = "Hobbit School";
        grade = "8";
        strongestSubject = "counting";
        weakestSubject = "spelling";
        testCompletionTime = "2 hours";
        String driverStatus = "has their driver's license";
        String futurePlans = "go to college";
        int collegeEntryExamScore = 1200;

        // set this data into the ElementarySchoolStudent object
        highSchoolStudent.setFirstName(firstName);
        highSchoolStudent.setLastName(lastName);
        highSchoolStudent.setSchool(school);
        highSchoolStudent.setGrade(grade);
        highSchoolStudent.setStrongestSubject(strongestSubject);
        highSchoolStudent.setWeakestSubject(weakestSubject);
        highSchoolStudent.setTestCompletionTime(testCompletionTime);
        highSchoolStudent.setDriverStatus(driverStatus);
        highSchoolStudent.setFuturePlans(futurePlans);
        highSchoolStudent.setCollegeEntryExamScore(collegeEntryExamScore);

        // create a String to hold the expected output
        expectedOutput = firstName + " "
                + lastName + " is a(n) " + grade + "th grader at "
                + school + ". " + firstName + " is adept in "
                + strongestSubject + ", but they could use some extra "
                + "practice in " + weakestSubject + ". "
                + firstName + " " + driverStatus + ", "
                + "and when they graduate they hope to "
                + futurePlans + ".";

        // create a String to hold the actual output
        actualOutput = highSchoolStudent.displayProgress();

        // compare the results and output SUCCESS/FAILURE
        System.out.println();
        System.out.println("Testing HighSchoolStudent displayProgress()...");
        System.out.println();

        if (expectedOutput.equals(actualOutput)) {
            System.out.println("SUCCESS!");
        } else {
            System.out.println("FAILURE. " + expectedOutput + " was expected, "
                    + "but " + actualOutput + " was returned.");
        }

        // PART 2: Test each if/else branch in the HighSchoolStudent's
        // getTestResults() method

        // high score
        highSchoolStudent = new HighSchoolStudent();

        // create some test variables
        firstName = "Samwise";
        lastName = "Gamgee";
        strongestSubject = "counting";
        weakestSubject = "spelling";
        testCompletionTime = "2 hours";
        collegeEntryExamScore = 1200;

        // set this data into the ElementarySchoolStudent object
        highSchoolStudent.setFirstName(firstName);
        highSchoolStudent.setLastName(lastName);
        highSchoolStudent.setStrongestSubject(strongestSubject);
        highSchoolStudent.setWeakestSubject(weakestSubject);
        highSchoolStudent.setTestCompletionTime(testCompletionTime);
        highSchoolStudent.setCollegeEntryExamScore(collegeEntryExamScore);

        // create a string to hold the expected output
        expectedOutput = firstName + " " + lastName
                + " completed the test in " + testCompletionTime
                + ". Their overall score is " + collegeEntryExamScore
                + ". This is a high score. " + firstName
                + " scored highest in " + strongestSubject
                + " and lowest in " + weakestSubject + ".";

        // create a string to hold the actual output
        actualOutput = highSchoolStudent.getTestResults();

        // compare the results and output SUCCESS/FAILURE
        System.out.println();
        System.out.println("Testing HighSchoolStudent getTestResults(), high score...");
        System.out.println();

        if (expectedOutput.equals(actualOutput)) {
            System.out.println("SUCCESS!");
        } else {
            System.out.println("FAILURE. " + expectedOutput + " was expected, "
                    + "but " + actualOutput + " was returned.");
        }

        // average score
        highSchoolStudent = new HighSchoolStudent();

        // create some test variables
        firstName = "Samwise";
        lastName = "Gamgee";
        strongestSubject = "counting";
        weakestSubject = "spelling";
        testCompletionTime = "2 hours";
        collegeEntryExamScore = 1100;

        // set this data into the ElementarySchoolStudent object
        highSchoolStudent.setFirstName(firstName);
        highSchoolStudent.setLastName(lastName);
        highSchoolStudent.setStrongestSubject(strongestSubject);
        highSchoolStudent.setWeakestSubject(weakestSubject);
        highSchoolStudent.setTestCompletionTime(testCompletionTime);
        highSchoolStudent.setCollegeEntryExamScore(collegeEntryExamScore);

        // create a string to hold the expected output
        expectedOutput = firstName + " " + lastName
                + " completed the test in " + testCompletionTime
                + ". Their overall score is " + collegeEntryExamScore
                + ". This is an average score. " + firstName
                + " scored highest in " + strongestSubject
                + " and lowest in " + weakestSubject + ".";

        // create a string to hold the actual output
        actualOutput = highSchoolStudent.getTestResults();

        // compare the results and output SUCCESS/FAILURE
        System.out.println();
        System.out.println("Testing HighSchoolStudent getTestResults(), average score...");
        System.out.println();

        if (expectedOutput.equals(actualOutput)) {
            System.out.println("SUCCESS!");
        } else {
            System.out.println("FAILURE. " + expectedOutput + " was expected, "
                    + "but " + actualOutput + " was returned.");
        }

        // low score
        highSchoolStudent = new HighSchoolStudent();

        // create some test variables
        firstName = "Samwise";
        lastName = "Gamgee";
        strongestSubject = "counting";
        weakestSubject = "spelling";
        testCompletionTime = "2 hours";
        collegeEntryExamScore = 980;

        // set this data into the ElementarySchoolStudent object
        highSchoolStudent.setFirstName(firstName);
        highSchoolStudent.setLastName(lastName);
        highSchoolStudent.setStrongestSubject(strongestSubject);
        highSchoolStudent.setWeakestSubject(weakestSubject);
        highSchoolStudent.setTestCompletionTime(testCompletionTime);
        highSchoolStudent.setCollegeEntryExamScore(collegeEntryExamScore);

        // create a string to hold the expected output
        expectedOutput = firstName + " " + lastName
                + " completed the test in " + testCompletionTime
                + ". Their overall score is " + collegeEntryExamScore
                + ". This is a relatively low score. " + firstName
                + " scored highest in " + strongestSubject
                + " and lowest in " + weakestSubject + ".";

        // create a string to hold the actual output
        actualOutput = highSchoolStudent.getTestResults();

        // compare the results and output SUCCESS/FAILURE
        System.out.println();
        System.out.println("Testing HighSchoolStudent getTestResults(), low score...");
        System.out.println();

        if (expectedOutput.equals(actualOutput)) {
            System.out.println("SUCCESS!");
        } else {
            System.out.println("FAILURE. " + expectedOutput + " was expected, "
                    + "but " + actualOutput + " was returned.");
        }
    }
}
