/** The ElementarySchoolStudent is a subclass of the GeneralStudent class
 *  which implements the TestTaker interface. It will contain some
 *  ElementarySchoolStudent-specific instance variables along with
 *  some methods required to override the displayProgress() method in
 *  the GeneralStudent superclass.
 *
 *  @author Elspeth Stalter-Clouse
 */
public class ElementarySchoolStudent extends GeneralStudent implements TestTaker {
    // ElementarySchoolStudent-specific instance variables
    private String favoriteRecessActivity;
    private String snackPack;
    private int standardizedTestScore;

    // get-and-set!

	/**
	* Returns value of favoriteRecessActivity
	* @return favoriteRecessActivity
	*/
	public String getFavoriteRecessActivity() {
		return favoriteRecessActivity;
	}

	/**
	* Sets new value of favoriteRecessActivity
	* @param favoriteRecessActivity
	*/
	public void setFavoriteRecessActivity(String favoriteRecessActivity) {
		this.favoriteRecessActivity = favoriteRecessActivity;
	}

	/**
	* Returns value of snackPack
	* @return snackPack
	*/
	public String getSnackPack() {
		return snackPack;
	}

	/**
	* Sets new value of snackPack
	* @param snackPack
	*/
	public void setSnackPack(String snackPack) {
		this.snackPack = snackPack;
	}

	/**
	* Returns value of standardizedTestScore
	* @return standardizedTestScore
	*/
	public int getStandardizedTestScore() {
		return standardizedTestScore;
	}

	/**
	* Sets new value of standardizedTestScore
	* @param standardizedTestScore
	*/
	public void setStandardizedTestScore(int standardizedTestScore) {
		this.standardizedTestScore = standardizedTestScore;
	}

    /** The displayProgress() method will override the method in the
     *  GeneralStudent superclass and output a progress report for an
     *  ElementarySchoolStudent object
     *  @return a progressReport String
     */
    public String displayProgress() {
        // A local variable to hold the progressReport String
        String progressReport = "";

        if (getGrade().equals("k")) {
            progressReport = getFirstName() + " "
                    + getLastName() + " is a kindergartener at " + getSchool()
                    + ". " + getFirstName() + " is adept in "
                    + getStrongestSubject() + ", but they could use some extra "
                    + "practice in " + getWeakestSubject() + ". During recess, "
                    + getFirstName() + " loves to " + getFavoriteRecessActivity()
                    + ", and their favorite snack is " + getSnackPack() + ".";
        } else if (getGrade().equals("1")) {
            progressReport = getFirstName() + " "
                    + getLastName() + " is a " + getGrade() + "st grader at "
                    + getSchool() + ". " + getFirstName() + " is adept in "
                    + getStrongestSubject() + ", but they could use some extra "
                    + "practice in " + getWeakestSubject() + ". During recess, "
                    + getFirstName() + " loves to " + getFavoriteRecessActivity()
                    + ", and their favorite snack is " + getSnackPack() + ".";
        } else if (getGrade().equals("2")) {
            progressReport = getFirstName() + " "
                    + getLastName() + " is a " + getGrade() + "nd grader at "
                    + getSchool() + ". " + getFirstName() + " is adept in "
                    + getStrongestSubject() + ", but they could use some extra "
                    + "practice in " + getWeakestSubject() + ". During recess, "
                    + getFirstName() + " loves to " + getFavoriteRecessActivity()
                    + ", and their favorite snack is " + getSnackPack() + ".";
        } else if (getGrade().equals("3")) {
            progressReport = getFirstName() + " "
                    + getLastName() + " is a " + getGrade() + "rd grader at "
                    + getSchool() + ". " + getFirstName() + " is adept in "
                    + getStrongestSubject() + ", but they could use some extra "
                    + "practice in " + getWeakestSubject() + ". During recess, "
                    + getFirstName() + " loves to " + getFavoriteRecessActivity()
                    + ", and their favorite snack is " + getSnackPack() + ".";
        } else {
            progressReport = getFirstName() + " "
                    + getLastName() + " is a " + getGrade() + "th grader at "
                    + getSchool() + ". " + getFirstName() + " is adept in "
                    + getStrongestSubject() + ", but they could use some extra "
                    + "practice in " + getWeakestSubject() + ". During recess, "
                    + getFirstName() + " loves to " + getFavoriteRecessActivity()
                    + ", and their favorite snack is " + getSnackPack() + ".";
        }

        return progressReport;
    }

    /** The takeTest() method will describe the test the student is taking.
     */
    public void takeTest() {
        System.out.println(System.lineSeparator() + getFirstName() + " "
                + getLastName() + " is taking a standardized test of basic "
                + "skills...");
    }

    /** The getTestResults() method will output the student's test time and
     *  test score
     *  @return String representing the student's results
     */
    public String getTestResults() {
        // A local variable to hold the testResults String
        String testResults = "";

        if (getStandardizedTestScore() >= 400) {
            testResults = getFirstName() + " " + getLastName()
                    + " completed the test in " + getTestCompletionTime()
                    + ". Their overall score is " + getStandardizedTestScore()
                    + ". This is a high score. " + getFirstName()
                    + " scored highest in " + getStrongestSubject()
                    + " and lowest in " + getWeakestSubject() + ".";
        } else if (getStandardizedTestScore() >= 275 &&
                getStandardizedTestScore() < 400) {
            testResults = getFirstName() + " " + getLastName()
                    + " completed the test in " + getTestCompletionTime()
                    + ". Their overall score is " + getStandardizedTestScore()
                    + ". This is an average score. " + getFirstName()
                    + " scored highest in " + getStrongestSubject()
                    + " and lowest in " + getWeakestSubject() + ".";
        } else if (getStandardizedTestScore() < 275) {
            testResults = getFirstName() + " " + getLastName()
                    + " completed the test in " + getTestCompletionTime()
                    + ". Their overall score is " + getStandardizedTestScore()
                    + ". This is a relatively low score. " + getFirstName()
                    + " scored highest in " + getStrongestSubject()
                    + " and lowest in " + getWeakestSubject() + ".";
        }

        // return the appropriate String to the caller
        return testResults;
    }
}
