/**
 *  Car class represents a car in the Vehicle system
 *
 *  @author Elspeth Stalter-Clouse
 */
class Car extends Vehicle {
    private int numberOfCylinders;

    /** returns value of numberOfCylinders
     * @return numberOfCylinders
     */
    public int getNumberOfCylinders() {
    	return numberOfCylinders;
    }

    /** Sets new value of numberOfCylinders
     * @param numberOfCylinders the numberOfCylinders to set
     */
    public void setNumberOfCylinders(int numberOfCylinders) {
    	this.numberOfCylinders = numberOfCylinders;
    }

    /**
     * @return a string representation of a car
     */
    public String toString() {
        return super.toString() + " It has " + numberOfCylinders + " cylinders.";
    }

    /** Drive the car
     */
    public void operate() {
        System.out.println("Driving the car.");
    }

    /** determines the cost of maintenance
     *  @return maintenance cost
     */
    public double determineMaintenanceCost() {
        return 250.00 * numberOfCylinders;
    }

}
