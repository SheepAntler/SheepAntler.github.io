/** Demonstrates polymorphism with Vehicle and its subclasses
 *
 *  @author Elspeth Stalter-Clouse
 *
/**
 * VehicleSuperSub
 */
class PolyTestDrive {
    /** Create an airplane and a car object, but the object reference variable
     *  type is vehicle \
     *  @param args command line args (not used here)
     */
    public static void main(String[] args) {
        // instantiate a Car
        Car car = new Car(); // for line 18 to work, you need Car on the left side of this!
        car.setMake("Toyota");
        car.setModel("Camry");
        car.setNumberOfCylinders(4);
        //car.setNumberOfCylinders(8);
        // THIS DOESN'T WORK! Leave a note in your lab explaining why you think it doesn't work...
        // I THINK IT IS BECAUSE you cannot inherit back up the chain! Inheritance only goes forwards.

        // instantiate an Airplane
        Vehicle plane = new Airplane();
        plane.setMake("Cirrus");
        plane.setModel("SR22");

        // toString() demo;
        System.out.println(car);
        System.out.println(plane);

    }

}
