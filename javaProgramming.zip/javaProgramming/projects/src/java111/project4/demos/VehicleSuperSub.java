/** Demonstrates creating instances of subclasses of the Vehicle
 *
 *  @author Elspeth Stalter-Clouse
 *
/**
 * VehicleSuperSub
 */
class VehicleSuperSub {
    /** Create an airplane and a car, and call
     *  the start method on each one
     */
    public static void main(String[] args) {
        // instantiate a Car
        Car car = new Car();
        car.setMake("Toyota");
        car.setModel("Camry");
        car.setYear(1992);
        car.setColor("maroon");
        car.setNumberOfCylinders(8);

        // instantiate an Airplane
        Airplane plane = new Airplane();
        plane.setMake("Cirrus");
        plane.setModel("SR22");
        plane.setYear(2018);
        plane.setColor("white");
        plane.setNumberOfEngines(2);

        //car.start();
        //plane.start();

        // toString() demo;
        System.out.println(car); // implicitly calls toString();
        System.out.println(plane.toString()); // this is the longer way...

    }

}
