// import!
import java.util.*;

/** The BuildStudentProgressReports class will create an ArrayList to hold
 *  student objects. It will also instantiate a new InputHelper object
 *  to get the user input that will set data into the instance variables
 *  describing each student object. It will contain methods that loop through
 *  the ArrayList of students, calling each object's methods and outputting
 *  data on each student to the terminal window.
 *
 *  @author Elspeth Stalter-Clouse
 */
public class BuildStudentProgressReports {
    // create an ArrayList to hold GeneralStudent objects
    private ArrayList<GeneralStudent> students;

    // instantiate a new InputHelper object
    InputHelper input = new InputHelper();

    /** The getStudentData() method will prompt the user to enter some data
     *  about new student objects. After collecting this data, it will set
     *  each new student object created by the user into the students ArrayList
     */
    public void getStudentData() {
        // instantiate the ArrayList
        students = new ArrayList<GeneralStudent>();

        // declare some local variables to temporarily hold student data
        String studentType = "";
        String firstName = "";
        String lastName = "";
        String school = "";
        String grade = "";
        String strongestSubject = "";
        String weakestSubject = "";
        String testCompletionTime = "";
        String favoriteRecessActivity = "";
        String snackPack = "";
        String standardizedTestScoreString = "";
        int standardizedTestScore = 0;
        String awkwardnessLevelString = "";
        int awkwardnessLevel = 0;
        String popularityString = "";
        int popularity = 0;
        String preparatoryTestScoreString = "";
        int preparatoryTestScore = 0;
        String driverStatus = "";
        String futurePlans = "";
        String collegeEntryExamScoreString = "";
        int collegeEntryExamScore = 0;
        ElementarySchoolStudent newElementarySchoolStudent = null;
        MiddleSchoolStudent newMiddleSchoolStudent = null;
        HighSchoolStudent newHighSchoolStudent = null;
        String addStudents = "";

        // loop user input prompts until the user enters "done"
        while (true) {
            // figure out what sort of student the user wants to add to the
            // ArrayList
            studentType = input.getUserInput("What sort of student are you "
                    + "adding to the Progress Report list?"
                    + System.lineSeparator() + "Enter \"elementary school\", "
                    + "\"middle school\", or " + "\"high school\":");

            if (studentType.equals("elementary school")
                    || studentType.equals("elementary school ")) {
                // create a new ElementarySchoolStudent object
                newElementarySchoolStudent = new ElementarySchoolStudent();

                // set the GeneralStudent instance variable values
                firstName = input.getUserInput("Enter the student's first name:");
                newElementarySchoolStudent.setFirstName(firstName);

                lastName = input.getUserInput("Enter the student's last name:");
                newElementarySchoolStudent.setLastName(lastName);

                school = input.getUserInput("Enter the name of the school that "
                        + newElementarySchoolStudent.getFirstName() + " attends:");
                newElementarySchoolStudent.setSchool(school);

                grade = input.getUserInput("Enter " + newElementarySchoolStudent.getFirstName()
                        + "\'s grade:");
                newElementarySchoolStudent.setGrade(grade);

                strongestSubject = input.getUserInput(newElementarySchoolStudent.getFirstName()
                        + "\'s strongest subject:");
                newElementarySchoolStudent.setStrongestSubject(strongestSubject);

                weakestSubject = input.getUserInput(newElementarySchoolStudent.getFirstName()
                        + "\'s weakest subject:");
                newElementarySchoolStudent.setWeakestSubject(weakestSubject);

                // set the ElementarySchoolStudent-specific values
                favoriteRecessActivity = input.getUserInput("During recess,"
                        + newElementarySchoolStudent.getFirstName() + " likes to:");
                newElementarySchoolStudent.setFavoriteRecessActivity(favoriteRecessActivity);

                snackPack = input.getUserInput("For snack, "
                        + newElementarySchoolStudent.getFirstName() + " likes to bring:");
                newElementarySchoolStudent.setSnackPack(snackPack);

                if (newElementarySchoolStudent.getGrade().equals("k")) {
                    students.add(newElementarySchoolStudent);
                } else {
                    testCompletionTime = input.getUserInput(newElementarySchoolStudent.getFirstName()
                            + " completed their standardized test in:");
                    newElementarySchoolStudent.setTestCompletionTime(testCompletionTime);

                    standardizedTestScoreString = input.getUserInput(newElementarySchoolStudent.getFirstName()
                            + "\'s score is:");
                    standardizedTestScore = Integer.parseInt(standardizedTestScoreString);
                    newElementarySchoolStudent.setStandardizedTestScore(standardizedTestScore);

                    // add this student to the ArrayList
                    students.add(newElementarySchoolStudent);
                }

            } else if (studentType.equals("middle school")
                    || studentType.equals("middle school ")) {
                // create a new MiddleSchoolStudent object
                newMiddleSchoolStudent = new MiddleSchoolStudent();

                // set the GeneralStudent instance variables
                firstName = input.getUserInput("Enter the student's first name:");
                newMiddleSchoolStudent.setFirstName(firstName);

                lastName = input.getUserInput("Enter the student's last name:");
                newMiddleSchoolStudent.setLastName(lastName);

                school = input.getUserInput("Enter the name of the school that "
                        + newMiddleSchoolStudent.getFirstName() + " attends:");
                newMiddleSchoolStudent.setSchool(school);

                grade = input.getUserInput("Enter " + newMiddleSchoolStudent.getFirstName()
                        + "\'s grade:");
                newMiddleSchoolStudent.setGrade(grade);

                strongestSubject = input.getUserInput(newMiddleSchoolStudent.getFirstName()
                        + "\'s strongest subject:");
                newMiddleSchoolStudent.setStrongestSubject(strongestSubject);

                weakestSubject = input.getUserInput(newMiddleSchoolStudent.getFirstName()
                        + "\'s weakest subject:");
                newMiddleSchoolStudent.setWeakestSubject(weakestSubject);

                // set the MiddleSchoolStudent-specific values
                awkwardnessLevelString = input.getUserInput(newMiddleSchoolStudent.getFirstName()
                        + "\'s awkwardnessLevel is:");
                awkwardnessLevel = Integer.parseInt(awkwardnessLevelString);
                newMiddleSchoolStudent.setAwkwardnessLevel(awkwardnessLevel);

                popularityString = input.getUserInput(newMiddleSchoolStudent.getFirstName()
                        + "\'s popularity score is:");
                popularity = Integer.parseInt(popularityString);
                newMiddleSchoolStudent.setPopularity(popularity);

                testCompletionTime = input.getUserInput(newMiddleSchoolStudent.getFirstName()
                        + " completed their pre-SAT test in:");
                newMiddleSchoolStudent.setTestCompletionTime(testCompletionTime);

                preparatoryTestScoreString = input.getUserInput(newMiddleSchoolStudent.getFirstName()
                        + "\'s score is:");
                preparatoryTestScore = Integer.parseInt(preparatoryTestScoreString);
                newMiddleSchoolStudent.setPreparatoryTestScore(preparatoryTestScore);

                // add this student to the ArrayList
                students.add(newMiddleSchoolStudent);

            } else {
                // create a new HighSchoolStudent
                newHighSchoolStudent = new HighSchoolStudent();

                // set the GeneralStudent instance variables
                firstName = input.getUserInput("Enter the student's first name:");
                newHighSchoolStudent.setFirstName(firstName);

                lastName = input.getUserInput("Enter the student's last name:");
                newHighSchoolStudent.setLastName(lastName);

                school = input.getUserInput("Enter the name of the school that "
                        + newHighSchoolStudent.getFirstName() + " attends:");
                newHighSchoolStudent.setSchool(school);

                grade = input.getUserInput("Enter " + newHighSchoolStudent.getFirstName()
                        + "\'s grade:");
                newHighSchoolStudent.setGrade(grade);

                strongestSubject = input.getUserInput(newHighSchoolStudent.getFirstName()
                        + "\'s strongest subject:");
                newHighSchoolStudent.setStrongestSubject(strongestSubject);

                weakestSubject = input.getUserInput(newHighSchoolStudent.getFirstName()
                        + "\'s weakest subject:");
                newHighSchoolStudent.setWeakestSubject(weakestSubject);

                driverStatus = input.getUserInput(newHighSchoolStudent.getFirstName()
                        + "\'s driver status (options: \"is in driver's ed\", "
                        + "\"has their driver's license\", or "
                        + "\"has no current plans to drive\"):");
                newHighSchoolStudent.setDriverStatus(driverStatus);

                futurePlans = input.getUserInput("Next year, "
                        + newHighSchoolStudent.getFirstName() + " plans to:");
                newHighSchoolStudent.setFuturePlans(futurePlans);

                testCompletionTime = input.getUserInput(newHighSchoolStudent.getFirstName()
                        + " completed their SAT test in:");
                newHighSchoolStudent.setTestCompletionTime(testCompletionTime);

                collegeEntryExamScoreString = input.getUserInput(newHighSchoolStudent.getFirstName()
                        + "\'s score is:");
                collegeEntryExamScore = Integer.parseInt(collegeEntryExamScoreString);
                newHighSchoolStudent.setCollegeEntryExamScore(collegeEntryExamScore);

                // add this student to the ArrayList
                students.add(newHighSchoolStudent);
            }

            System.out.println(System.lineSeparator());

            addStudents = input.getUserInput("If you have more students to "
                    + "enter, please type \"more\". However, if you have "
                    + "entered your complete student list, please type "
                    + "\"done\".");

            System.out.println(System.lineSeparator());

            if (!addStudents.equals("more")) {
                break;
            }
        }
    }

    /** The processProgressReports method will loop through the ArrayList of
     *  students and call each student's methods
     */
    public void processProgressReports() {
        // loop through the ArrayList
        for (GeneralStudent student : students) {
            if (student.getGrade().equals("k")) {
                // new student banner
                System.out.println();
                System.out.println("++++++++++++++++++++++++");
                System.out.println("+++ NEW STUDENT DATA +++");
                System.out.println("++++++++++++++++++++++++");
                System.out.println();

                System.out.println(student.displayProgress());
                System.out.println("Because " + student.getFirstName()
                        + " is in kindergarten, their slog through "
                        + "standardized testing has yet to begin. "
                        + "No test scores to see here!");
            } else {
                // New Student Banner
                System.out.println();
                System.out.println("++++++++++++++++++++++++");
                System.out.println("+++ NEW STUDENT DATA +++");
                System.out.println("++++++++++++++++++++++++");
                System.out.println();

                System.out.println(student.displayProgress());
                student.takeTest();
                System.out.println(System.lineSeparator()
                        + student.getTestResults());
            }
        }
    }


    /** This is the run() method. It has both methods from this class contained
     *  in a neat little package!
     */
    public void run() {
        // output some precursory information
        System.out.println();
        System.out.println("==============================");
        System.out.println("******* WELCOME TO THE *******");
        System.out.println("*** PUPIL PROGRESS PRINTER ***");
        System.out.println("==============================");
        System.out.println();
        System.out.println("It's exam week, and everyone is stressed. I'm here "
                + "to make your life easier by helping you catalogue students' "
                + "test results!");
        System.out.println();

        getStudentData();

        // output another label for organized results
        System.out.println();
        System.out.println("================================");
        System.out.println("********* HERE ARE THE *********");
        System.out.println("*** PUPILS' PROGRESS REPORTS ***");
        System.out.println("******* AND TEST RESULTS *******");
        System.out.println("================================");
        System.out.println();

        processProgressReports();
    }

}
