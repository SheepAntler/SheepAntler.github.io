/** This is the test code for Part 1 of Project 4. It will contain a main method
 *  that instantiates an object from the Student class and an object from the
 *  Kindergarten class, sets some sample data for each, and outputs
 *  SUCCESS/FAILURE messages based on whether the resulting output is
 *  the expected output or not.
 *
 *  @author Elspeth Stalter-Clouse
 */
public class Part1TestCode {
    /** The main method!
     *  @param args command line arguments
     */
    public static void main(String[] args) {

        // Test Case 1: Instantiate a Student
        Student testStudent = new Student();

        // create some test variables
        String firstName = "Pauline";
        String lastName = "Parrot";
        int studentId = 555;
        String schoolName = "Please Work High";
        String extracurriculars = "building excel spreadsheets";
        String homeroomTeacher = "Mx. Success";

        // set the data into the Student object
        testStudent.setStudentFirstName(firstName);
        testStudent.setStudentLastName(lastName);
        testStudent.setStudentId(studentId);
        testStudent.setSchoolName(schoolName);
        testStudent.setExtracurriculars(extracurriculars);
        testStudent.setHomeroomTeacher(homeroomTeacher);

        // set a String to the expected output
        String expectedOutput = firstName + " " + lastName + " is in "
                + homeroomTeacher + "'s homeroom at " + schoolName
                + " and has Student ID number " + studentId
                + ". When not in school, " + firstName + " enjoys "
                + extracurriculars + ".";

        // create a String to hold the actual output
        String actualOutput = testStudent.toString();

        // compare the two Strings and output a Success or Failure message
        // based on the result
        System.out.println();
        System.out.println("Test Case 1: Instantiate a STUDENT object...");
        System.out.println();

        if (actualOutput.equals(expectedOutput)) {
            System.out.println("SUCCESS!");
        } else {
            System.out.println("Student instantiation FAILED. " + expectedOutput
                    + " was expected, but " + actualOutput + " was returned.");
        }

        // Test Case 2: Instantiate a Student
        KindergartenStudent testKindergartenStudent = new KindergartenStudent();

        // create some test variables
        firstName = "Sasparilla";
        lastName = "Salamander";
        studentId = 222;
        schoolName = "Please Work Elementary";
        extracurriculars = "building with blocks";
        homeroomTeacher = "Mx. Antje";
        String showAndTellItem = "a bag of buttons";


        // set the data into the KindergartenStudent object
        testKindergartenStudent.setStudentFirstName(firstName);
        testKindergartenStudent.setStudentLastName(lastName);
        testKindergartenStudent.setStudentId(studentId);
        testKindergartenStudent.setSchoolName(schoolName);
        testKindergartenStudent.setExtracurriculars(extracurriculars);
        testKindergartenStudent.setHomeroomTeacher(homeroomTeacher);
        testKindergartenStudent.setShowAndTellItem(showAndTellItem);

        // set a String to the expected output
        expectedOutput = firstName + " " + lastName + " is in "
                + homeroomTeacher + "'s homeroom at " + schoolName
                + " and has Student ID number " + studentId
                + ". When not in school, " + firstName + " enjoys "
                + extracurriculars + ". " + firstName + " is in kindergarten "
                + "and will be bringing " + showAndTellItem
                + " to Show-And-Tell this week.";

        // create a String to hold the actual output
        actualOutput = testKindergartenStudent.toString();

        // compare the two Strings and output a Success or Failure message
        // based on the result
        System.out.println();
        System.out.println("Test Case 1: Instantiate a KINDERGARTEN STUDENT object...");
        System.out.println();

        if (actualOutput.equals(expectedOutput)) {
            System.out.println("SUCCESS!");
        } else {
            System.out.println("Kindergarten Student instantiation FAILED. "
                    + expectedOutput + " was expected, but "
                    + actualOutput + " was returned.");
        }
    }
}
