// import!
import java.util.*;

/** The LearnerList class will create and populate an ArrayList of both
 *  general Student objects and objects from the KindergartenStudent's
 *  subclass.
 *
 *  @author Elspeth Stalter-Clouse
 */
public class LearnerList {
    // Create an ArrayList to hold Student objects
    private ArrayList<Student> learnerList;

    /** This method will populate the learnerList ArrayList with Student and
     *  KindergartenStudent objects
     */
    public void createLearnerList() {
        // instantiate the ArrayList
        learnerList = new ArrayList<Student>();

        // Create and instantiate some student objects from both
        // the Student superclass and the KindergartenStudent subclass
        Student student1 = new Student();
        // set data
        student1.setStudentFirstName("John");
        student1.setStudentLastName("Doe");
        student1.setStudentId(792);
        student1.setSchoolName("Kensington High School");
        student1.setExtracurriculars("horseback riding");
        student1.setHomeroomTeacher("Jeremy Djinn");
        // put this object into the ArrayList
        learnerList.add(student1);

        KindergartenStudent kindergartener1 = new KindergartenStudent();
        // set data
        kindergartener1.setStudentFirstName("Mimsy");
        kindergartener1.setStudentLastName("Ginsborough");
        kindergartener1.setStudentId(123);
        kindergartener1.setSchoolName("Kensington Elementary");
        kindergartener1.setExtracurriculars("coloring");
        kindergartener1.setHomeroomTeacher("Elsa Ingels");
        kindergartener1.setShowAndTellItem("her 12 gerbils");
        // put this object into the ArrayList
        learnerList.add(kindergartener1);

        Student student2 = new Student();
        // set data
        student2.setStudentFirstName("Jane");
        student2.setStudentLastName("Doe");
        student2.setStudentId(046);
        student2.setSchoolName("Kensington High School");
        student2.setExtracurriculars("fencing and knitting");
        student2.setHomeroomTeacher("Jill Sykes");
        // put this object into the ArrayList
        learnerList.add(student2);

        KindergartenStudent kindergartener2 = new KindergartenStudent();
        // set data
        kindergartener2.setStudentFirstName("Bobby");
        kindergartener2.setStudentLastName("Fox");
        kindergartener2.setStudentId(414);
        kindergartener2.setSchoolName("Kensington Elementary");
        kindergartener2.setExtracurriculars("catching bugs and swimming");
        kindergartener2.setHomeroomTeacher("Stephen Smarts");
        kindergartener2.setShowAndTellItem("a jar of worms");
        // put this object into the ArrayList
        learnerList.add(kindergartener2);
    }

    /** This method will loop through the ArrayList of students and call
     *  each Student object's toString() method
     */
    public void displayStudents() {
        // use an enhanced for loop!
        for (Student student : learnerList) {
            System.out.println();
            System.out.println(student.toString());
        }
    }
}
