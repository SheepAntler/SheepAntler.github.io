/** This is the test drive for the Messenger class and its subclass. It will
 *  instantiate one instance of each object and call their displayGreeting()
 *  methods.
 *
 *  @author Elspeth Stalter-Clouse
 */
public class MessengerTestDrive {
    /** The main method!
     *  @param args
     */
    public static void main(String[] args) {
        // instantiate each object
        Messenger messengerTest = new Messenger();
        SpanishMessenger spanishMessengerTest = new SpanishMessenger();

        // do a tiny, tiny bit of setting for SpanishMessenger
        spanishMessengerTest.setMessengerName("SpanishMessenger");

        // call the displayGreeting() methods
        messengerTest.displayGreeting();
        spanishMessengerTest.displayGreeting();
    }
}
