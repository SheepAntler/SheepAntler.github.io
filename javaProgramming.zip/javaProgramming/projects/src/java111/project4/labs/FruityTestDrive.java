/** This is the SECOND test drive for the Fruit class and its subclasses/their
 *  their subclasses. It will instantiate three objects and call their
 *  displayClassName() methods.
 *
 *  @author Elspeth Stalter-Clouse
 */
public class FruityTestDrive {
    /** Here is the main method:
     *  @param args
     */
    public static void main(String[] args) {
        // Instantiate the three objects
        Fruit fruit = new Fruit();
        Fruit plum = new Plum();
        Fruit prune = new Prune();

        // call the displayClassName() method on each object
        fruit.displayClassName();
        plum.displayClassName();
        prune.displayClassName();

        /** CAUTION CAUTION CAUTION CAUTION
         *  *****ILLEGAL METHOD CALLS!*****
         *  CAUTION CAUTION CAUTION CAUTION
         */

        //plum.displayPlumPoem();
        //prune.displayPrunePoem();



    }
}
