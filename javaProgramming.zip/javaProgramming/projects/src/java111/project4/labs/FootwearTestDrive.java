/** This is the main method for the Footwear superclass and its Boot subclass.
 *  It will instantiate objects of each type and call their display() methods.
 */
public class FootwearTestDrive {
    /** The main method!
     *  @param args
     */
    public static void main(String[] args) {
        // instantiate a few footwear objects
        Footwear footwearOne = new Footwear();
        footwearOne.setBrand("Birkenstock");
        footwearOne.setColor("red");
        footwearOne.setSoleType("cork");
        footwearOne.setSize(8.5);

        Footwear footwearTwo = new Footwear();
        footwearTwo.setBrand("Chaco");
        footwearTwo.setColor("rainbow");
        footwearTwo.setSoleType("rubber");
        footwearTwo.setSize(8);

        // instantiate a few boot objects
        Boot bootOne = new Boot();
        bootOne.setBrand("Boggs");
        bootOne.setColor("green");
        bootOne.setSoleType("rubber");
        bootOne.setSize(9);
        bootOne.setBootHeight("knee-high");
        bootOne.setBootMaterial("rubber");
        bootOne.setBootWeather("rainy");

        Boot bootTwo = new Boot();
        bootTwo.setBrand("Sorel");
        bootTwo.setColor("brown");
        bootTwo.setSoleType("rubber");
        bootTwo.setSize(8.5);
        bootTwo.setBootHeight("mid-calf");
        bootTwo.setBootMaterial("leather");
        bootTwo.setBootWeather("snowy/winter");

        // Call each object's display() method
        System.out.println();
        System.out.println("In my shoe closet, I have...");
        footwearOne.display();
        footwearTwo.display();
        bootOne.display();
        bootTwo.display();
        System.out.println();
    }
}
