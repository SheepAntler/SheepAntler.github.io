/** This class will test the display() method in the Bird class
 *  by instantiating a BlackThroatedBlueWarbler object and calling the
 *  display() method within it
 *
 *  @author Elspeth Stalter-Clouse
 */
public class BirdTestDrive {
    /** Here's the main method!
     *  @param args
     */
    public static void main(String[] args) {
        // instantiate a BlackThroatedBlueWarbler object
        System.out.println(System.lineSeparator() + "For my own edification, "
                + "I am instantiating a BlackThroatedBlueWarbler object "
                + "from both the Bird and BlackThroatedBlueWarbler classes.");
        Bird birdy = new BlackThroatedBlueWarbler();
        BlackThroatedBlueWarbler warbler = new BlackThroatedBlueWarbler();

        // call its display method
        birdy.display();
        warbler.display();
    }
}
