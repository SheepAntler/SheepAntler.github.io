/** This class represents a Prune object. It extends the Plum class and
 *  contains a single method, which will output the name of this class.
 *
 *  @author Elspeth Stalter-Clouse
 */
public class Prune extends Plum {
    // display the class
    public void displayClassName() {
        System.out.println(System.lineSeparator() + "Hi! I'm from the prune "
                + "class. Prunes may be dried plums, but they taste so different!");
    }

    // A special Prune method...
    public void displayPrunePoem() {
        System.out.println("There once was a prune from a box");
        System.out.println("Who loved to eat bagels and lox.");
        System.out.println("It got nice and plump");
        System.out.println("But rolled into a dump");
        System.out.println("Where it got devoured by a fox.");
    }
}
