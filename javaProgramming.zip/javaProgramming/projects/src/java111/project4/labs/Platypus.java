/** The Platypus class extends the Animal class. It does not contain
 *  any variables or methods.
 *
 *  @author Elspeth Stalter-Clouse
 */
public class Platypus extends Animal {
    
}
