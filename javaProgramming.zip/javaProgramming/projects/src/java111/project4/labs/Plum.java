/** This class represents a Plum object. It extends the Fruit class and
 *  contains a single method, which will output the name of this class.
 *
 *  @author Elspeth Stalter-Clouse
 */
public class Plum extends Fruit {
    // display the class
    public void displayClassName() {
        System.out.println(System.lineSeparator() + "Hi! I'm from the plum "
                + "class! Plums are super sweet fruits.");
    }

    // A special Plum method...
    public void displayPlumPoem() {
        System.out.println("Roses are Red, violets are blue");
        System.out.println("Plums are quite sweet");
        System.out.println("But what else is new?");
    }
}
