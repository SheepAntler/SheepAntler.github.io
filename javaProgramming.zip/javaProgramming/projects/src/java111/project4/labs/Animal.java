/** This class represents an Animal object.
 *  It contains a lonely display method.
 *
 *  @author Elspeth Stalter-Clouse
 */
public abstract class Animal {
    /** This is the display method, which prints the class name to the
     *  terminal window.
     */
    public void display() {
        System.out.println(System.lineSeparator() + "I am an ANIMAL from the "
                + getClass() + ". " + System.lineSeparator());
    }
}
