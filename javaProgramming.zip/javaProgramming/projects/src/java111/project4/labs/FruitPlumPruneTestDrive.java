/** This is the FIRST test drive for the Fruit class and its subclasses/their
 *  their subclasses. It will instantiate three objects and call their
 *  displayClassName() methods.
 *
 *  @author Elspeth Stalter-Clouse
 */
public class FruitPlumPruneTestDrive {
    /** Here is the main method:
     *  @param args
     */
    public static void main(String[] args) {
        // Instantiate the three objects
        Fruit fruit = new Fruit();
        Plum plum = new Plum();
        Prune prune = new Prune();

        // call the displayClassName() method on each object
        fruit.displayClassName();
        plum.displayClassName();
        prune.displayClassName();

    }
}
