/** the Event interface is for any item
 *  that requires scheduling
 *
 *  @author Elspeth Stalter-Clouse
 */
public interface Event {
    // Here is the abstract display() method
    public abstract void display();
}
