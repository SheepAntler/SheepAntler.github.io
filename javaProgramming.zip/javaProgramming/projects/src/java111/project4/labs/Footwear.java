/** This class represents a Footwear object. It will contain some variables
 *  pertaining to Footwear objects, their get and set methods, and a display()
 *  method to output this information
 *
 *  @author Elspeth Stalter-Clouse
 */
public class Footwear {
    // Instance variable declaration
    private String brand;
    private String color;
    private String soleType;
    private double size;

    // get-and-set!
    /** get the brand name
     *  @return brand
     */
    public String getBrand() {
        return brand;
    }

    /** set the brand name
     *  @param brand
     */
    public void setBrand(String brand) {
        this.brand = brand;
    }

    /** get the color
     *  @return color
     */
    public String getColor() {
        return color;
    }

    /** set the color
     *  @param color
     */
    public void setColor(String color) {
        this.color = color;
    }

    /** get the soleType
     *  @return soleType
     */
    public String getSoleType() {
        return soleType;
    }

    /** set the soleType
     *  @param soleType
     */
    public void setSoleType(String soleType) {
        this.soleType = soleType;
    }

    /** get the size
     *  @return size
     */
    public double getSize() {
        return size;
    }

    /** set the size
     *  @param size
     */
    public void setSize(double size) {
        this.size = size;
    }

    // This is the display method, which will output the footwear instance
    // variables to the terminal window
    public void display() {
        System.out.println();
        System.out.println("- a pair of " + color + " " + brand + "s with "
                + soleType + " soles, size " + String.format("%.1f", size));
    }

}
