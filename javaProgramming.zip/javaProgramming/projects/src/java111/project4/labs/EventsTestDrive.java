// import!
import java.util.*;

/** This is the test drive for the Meeting and Marathon classes, which
 *  implement the Event interface.
 *
 *  @author Elspeth Stalter-Clouse
 */
public class EventsTestDrive {
    /** Here is the main method
     *  @param args
     */
    public static void main(String[] args) {
        // instantiate an object from the Meeting class
        // and one from the Event class (that won't compile, sadly)
        Meeting meeting = new Meeting();

        /** This won't compile because
         *  it is an abstract class
         */
        //Event event = new Event();

        // here is an ArrayList for the test drive
        ArrayList<Event> events = new ArrayList<Event>();

        // create new instances of each event
        Event event1 = new Meeting();
        Event event2 = new Marathon();

        // add them to the ArrayList
        events.add(event1);
        events.add(event2);

        // loop through the ArrayList and call each event's display() method
        for (Event event : events) {
            event.display();
        }






    }
}
