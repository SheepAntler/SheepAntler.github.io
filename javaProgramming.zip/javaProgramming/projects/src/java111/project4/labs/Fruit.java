/** This class represents a Fruit object. It contains a single method,
 *  which will output the name of this class.
 *
 *  @author Elspeth Stalter-Clouse
 */
public class Fruit {
    // display the class
    public void displayClassName() {
        System.out.println(System.lineSeparator() + "Hi! I'm from the fruit "
                + "class!");
    }
}
