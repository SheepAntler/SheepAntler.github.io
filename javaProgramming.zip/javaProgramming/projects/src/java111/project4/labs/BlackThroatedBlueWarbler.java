/** This class extends the Bird class
 *
 *  @author Elspeth Stalter-Clouse
 */
public class BlackThroatedBlueWarbler extends Bird {
    /** The display() method in this class overrides
     *  the display() method in the Bird class
     */
    public void display() {
        System.out.println(System.lineSeparator() + "the bird, bird, bird");
        System.out.println("the bird is the word" + System.lineSeparator()); 
    }
}
