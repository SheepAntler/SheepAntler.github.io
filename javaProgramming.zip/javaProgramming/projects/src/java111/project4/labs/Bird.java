/** This class contains an abstract display method
 *
 *  @author Elspeth Stalter-Clouse
 */
public abstract class Bird {
    /** The display() method will print the name
     *  of the Bird class to the terminal window
     */
    public abstract void display();
}
