/** This class represents a SpanishMessenger object. It will contain some instance
 *  variables and a displayGreeting() method of its own.
 *
 *  @author Elspeth Stalter-Clouse
 */
public class SpanishMessenger extends Messenger {

    // The displayGreeting() method, which will output a short message.
    public void displayGreeting() {
        System.out.println("Hola from the " + getMessengerName() + ", too!"
                + System.lineSeparator());
    }
}
