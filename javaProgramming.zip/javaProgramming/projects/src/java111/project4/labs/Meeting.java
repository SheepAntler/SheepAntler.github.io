/** This class implements the Event interface
 *
 *  @author Elspeth Stalter-Clouse
 */
public class Meeting implements Event {

    /** I must override the abstract display() method
     *  in the Event interface for EventsTestDrive to compile
     *  because it is an abstract method!
     */
    public void display() {
        System.out.println(System.lineSeparator() + "STORYTIME: THE MEETING"
                + System.lineSeparator() + "Dorothy closed her eyes "
                + "and clicked her Ruby Slippers together three times. "
                + "\" There's no place like home. There's no place like home. "
                + "There's no place like home.\" She intoned. There was a rush "
                + "of air followed by strange sounds and flashing lights. "
                + "Then everything was still. Dorothy's eyes snapped open, "
                + "and her face fell in dismay. SHE WAS RIGHT BACK AT THE "
                + "DEPARTMENT MEETING SHE'D SO DESPERATELY BEEN TRYING TO "
                + "AVOID! That whole journey through Oz...worthless. It was "
                + "then that she noticed boss did look suspciously like that "
                + "scarecrow she'd met on the yellow brick road...");
    }
}
