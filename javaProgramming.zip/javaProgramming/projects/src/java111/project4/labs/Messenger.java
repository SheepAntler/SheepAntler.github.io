/** This class represents a Messenger object. It will contain some instance
 *  variables and a displayGreeting() method.
 *
 *  @author Elspeth Stalter-Clouse
 */
public class Messenger {
    // Instance variables
    private String messengerName = "Messenger";

    // get-and-set
    /** get the messengerName
     *  @return messengerName
     */
    public String getMessengerName() {
        return messengerName;
    }

    /** set the messengerName
     *  @param messengerName
     */
    public void setMessengerName(String messengerName) {
        this.messengerName = messengerName;
    }

    // The displayGreeting() method, which will output a short message.
    public void displayGreeting() {
        System.out.println(System.lineSeparator() + "Hello from the "
                + messengerName + "!" + System.lineSeparator());
    }
}
