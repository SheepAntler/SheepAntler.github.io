/** This class implements the Event interface
 *
 *  @author Elspeth Stalter-Clouse
 */
public class Marathon implements Event {

    /** I must override the abstract display() method
     *  in the Event interface for EventsTestDrive to compile
     *  because it is an abstract method!
     */
    public void display() {
        System.out.println(System.lineSeparator() + "STORYTIME: THE MARATHON"
                + System.lineSeparator() + "The day of the marathon "
                + "turned out to be dark and damp. The sky was a forbidding "
                + "shade of grey and he wasn't sure he wanted to brave the "
                + "elements to achieve a goal he'd only dreamt up earlier "
                + "that year. Staying home with the cats was starting to sound "
                + "pretty good...and that's when the doorbell rang."
                + System.lineSeparator());
    }
}
