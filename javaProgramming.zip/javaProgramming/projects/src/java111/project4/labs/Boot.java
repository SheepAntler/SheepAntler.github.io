/** This class represents a Boot object, which extends the Footwear class.
 *  It will add a few instance variables (with their get-and-set methods,
 *  of course!) and its own display() method
 *
 *  @author Elspeth Stalter-Clouse
 */
public class Boot extends Footwear {
    // Instance variable declaration
    private String bootHeight;
    private String bootWeather;
    private String bootMaterial;

    // get-and-set!
    /** get the bootHeight
     *  @return bootHeight
     */
    public String getBootHeight() {
        return bootHeight;
    }

    /** set the bootHeight
     *  @param bootHeight
     */
    public void setBootHeight(String bootHeight) {
        this.bootHeight = bootHeight;
    }

    /** get the bootWeather
     *  @return bootWeather
     */
    public String getBootWeather() {
        return bootWeather;
    }

    /** set the bootWeather
     *  @param bootWeather
     */
    public void setBootWeather(String bootWeather) {
        this.bootWeather = bootWeather;
    }

    /** get the bootMaterial
     *  @return bootMaterial
     */
    public String getBootMaterial() {
        return bootMaterial;
    }

    /** set the bootMaterial
     *  @param bootMaterial
     */
    public void setBootMaterial(String bootMaterial) {
        this.bootMaterial = bootMaterial;
    }

    // This is the display method, which will output the footwear and boot
    // instance variables to the terminal window
    public void display() {
        System.out.println();
        System.out.println("- a pair of " + getColor() + " " + bootMaterial
                + " " + bootHeight + " " + getBrand() + " boots with "
                + getSoleType() + " soles (perfect " + "for " + bootWeather
                + " weather!), size " + String.format("%.1f", getSize()));
    }
}
