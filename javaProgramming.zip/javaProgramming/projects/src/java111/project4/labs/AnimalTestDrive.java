/** This is the test drive for the Animal class. It will instantiate
 *  both it and its subclass object and call the display() method
 *
 *  @author Elspeth Stalter-Clouse
 */
public class AnimalTestDrive {
    /** Here's the main method!
     *  @param args
     */
    public static void main(String[] args) {
        // PART 1: Let's try instantiating an Animal object!

        /** Aaaaaaaand big surprise, we can't instantiate
            said animal object because it's abstract. Let's comment
            this out, shall we?

        // instantiate an Animal object
        Animal animal = new Animal();
        // call the display method
        animal.display();

        */

        // PART 2: Let's try instantiating an extension of the abstract
        // animal superclass instead...

        // instantiate a Platypus object
        Animal platypus = new Platypus();
        // call the display method
        platypus.display();

        // IT WORKS NOW!

        /** NOTE TO SELF: If you had a method in the Platypus class, you
         *  wouldn't be able to call it if the type was still Animal on the
         *  left side; you'd have to change that to Platypus, too, for the
         *  Platypus-specific method to work.
         */ 
    }
}
