/** The TestTaker interface will be implemented in the subclasses of
 *  the GeneralStudent class. It will contain two abstract methods.
 *
 *  @author Elspeth Stalter-Clouse
 */
public interface TestTaker {
    /** These methods will both be implemented in the instances of the
     *  subclasses of the GeneralStudent class.
     */
    public abstract void takeTest();

    public abstract String getTestResults();
}
