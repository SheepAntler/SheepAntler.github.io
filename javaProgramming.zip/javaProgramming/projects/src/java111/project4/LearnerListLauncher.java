/** The LearnerListLauncher class will instantiate a LearnerList object
 *  and call its createLearnerList() and display() methods.
 *
 *  @author Elspeth Stalter-Clouse
 */
public class LearnerListLauncher {
    /** Here is the main method!
     *  @param args
     */
    public static void main(String[] args) {
        // instantiate a new LearnerList object
        LearnerList learnerList = new LearnerList();

        // call the object's methods
        learnerList.createLearnerList();
        learnerList.displayStudents();
    }
}
