/** The Student class will hold information about general Student objects.
 *  It houses some instance variables, their get/set methods, and a toString()
 *  method that will contain a String representation of a Student object.
 *
 *  @author Elspeth Stalter-Clouse
 */
public class Student {
    // instance variables
    private String studentFirstName;
    private String studentLastName;
    private int studentId;
    private String schoolName;
    private String extracurriculars;
    private String homeroomTeacher;

    // get-and-set!
    /** get studentFirstName
     *  @return studentFirstName
     */
    public String getStudentFirstName() {
        return studentFirstName;
    }

    /** setStudentFirstName
     *  @param studentFirstName
     */
    public void setStudentFirstName(String studentFirstName) {
        this.studentFirstName = studentFirstName;
    }

    // get-and-set!
    /** get studentLastName
     *  @return studentLastName
     */
    public String getStudentLastName() {
        return studentLastName;
    }

    /** setStudentName
     *  @param studentLastName
     */
    public void setStudentLastName(String studentLastName) {
        this.studentLastName = studentLastName;
    }

    /** get studentId
     *  @return studentId
     */
    public int getStudentId() {
        return studentId;
    }

    /** set studentId
     *  @param studentId
     */
    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    /** get schoolName
     *  @return schoolName
     */
    public String getSchoolName() {
        return schoolName;
    }

    /** set schoolName
     *  @param schoolName
     */
    public void setSchoolName(String schoolName) {
        this.schoolName = schoolName;
    }

    /** get extracurriculars
     *  @return extracurriculars
     */
    public String getExtracurriculars() {
        return extracurriculars;
    }

    /** set extracurriculars
     *  @param extracurriculars
     */
    public void setExtracurriculars(String extracurriculars) {
        this.extracurriculars = extracurriculars;
    }

    /** get homeroomTeacher
     *  @return homeroomTeacher
     */
    public String getHomeroomTeacher() {
        return homeroomTeacher;
    }

    /** set homeroomTeacher
     *  @param homeroomTeacher
     */
    public void setHomeroomTeacher(String homeroomTeacher) {
        this.homeroomTeacher = homeroomTeacher;
    }

    /** This method is a String representation of a Student object.
     *  @return String description of a student
     */
    public String toString() {
        return studentFirstName + " " + studentLastName + " is in "
                + homeroomTeacher + "'s homeroom at " + schoolName
                + " and has Student ID number " + studentId + ". "
                + "When not in school, " + studentFirstName + " enjoys "
                + extracurriculars + ".";
    }
}
