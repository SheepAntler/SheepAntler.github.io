// import!
import java.util.*;

/** This class is the test drive for the BankAccount superclass and its
 *  subclasses. It will create an ArrayList that holds a couple instances
 *  of each subclass and loop through the ArrayList, calling each
 *  of the superclass's implemented methods from the subclasses
 *
 *  @author Elspeth Stalter-Clouse
 */
public class BankAccountTestDrive {
    /** Here is the main method
     *  @param args
     */
    public static void main(String[] args) {
        // create an ArrayList
        ArrayList<BankAccount> accounts = new ArrayList<BankAccount>();

        // instantiate some objects from each subclass
        // and set their start values
        BankAccount autoLoan1 = new AutoLoan();
        autoLoan1.setBalance(15000);
        autoLoan1.setAccountName("Auto Loan 1");
        autoLoan1.setCreditAmount(500);
        autoLoan1.setDebitAmount(200);

        BankAccount checking1 = new CheckingAccount();
        checking1.setBalance(800);
        checking1.setAccountName("Checking Account 1");
        checking1.setCreditAmount(500);
        checking1.setDebitAmount(200);

        // add these items to the array
        accounts.add(autoLoan1);
        accounts.add(checking1);

        System.out.println();

        // loop through the ArrayList and call each subclass's
        // implemented methods from the superclass
        for (BankAccount account : accounts) {
                System.out.println(account.getAccountName() + " has a balance of $"
                        + String.format("%,.2f", account.getBalance()) + ".");
        }

        System.out.println();

        System.out.println("Crediting accounts $500.00...");
                //+ String.format("%,.2f", account.getCreditAmount()));

        System.out.println();

        for (BankAccount account : accounts) {
            System.out.println(account.getAccountName() + " has a balance of $"
                    + String.format("%,.2f", account.creditAccount(account.getCreditAmount())));

            account.setBalance(account.creditAccount(account.getCreditAmount()));
        }

        System.out.println();

        System.out.println("Debiting accounts $200.00...");

        System.out.println();

        for (BankAccount account : accounts) {
            System.out.println(account.getAccountName() + " has a balance of $"
                    + String.format("%,.2f", account.debitAccount(account.getDebitAmount())));
        }
    }
}
