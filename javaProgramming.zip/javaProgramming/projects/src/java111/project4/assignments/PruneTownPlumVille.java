// import, import, import!
import java.util.*;

/** This class will create an ArrayList to hold several Plum and Prune objects,
 *  which are both subclasses of the Fruit class.
 *  It will then loop through this ArrayList and call the displayClassName()
 *  methods of the Plum and Prune objects in it.
 *
 *  @author Elspeth Stalter-Clouse
 */
public class PruneTownPlumVille {
    // Part 1: Create an ArrayList to hold Fruit objects
    ArrayList<Fruit> twoFruits;

    /** The createPlumPruneFruits() method, which will instantiate
     *  the twoFruits ArrayList and create Fruit objects to populate it
     *  (in Plum/Prune extended form!)
     */
    public void createPlumPruneFruits() {
        // Create several Plum and Prune objects
        Fruit plumOne = new Plum();
        plumOne.setFruitType("plum");

        Fruit pruneOne = new Prune();
        pruneOne.setFruitType("prune");

        Fruit plumTwo = new Plum();
        plumTwo.setFruitType("plum");

        Fruit pruneTwo = new Prune();
        pruneTwo.setFruitType("prune");

        Fruit plumThree = new Plum();
        plumThree.setFruitType("plum");

        Fruit pruneThree= new Prune();
        pruneThree.setFruitType("prune");

        // Instantiate the ArrayList and add the Plum and Prune objects to it
        twoFruits = new ArrayList<Fruit>();
        twoFruits.add(plumOne);
        twoFruits.add(pruneOne);
        twoFruits.add(plumTwo);
        twoFruits.add(pruneTwo);
        twoFruits.add(plumThree);
        twoFruits.add(pruneThree);
    }

    /** This method will loop through the ArrayList and call each object's
     *  displayClassName() method
     */
    public void displayPlumPruneFruits() {
        for (Fruit plumOrPrune : twoFruits) {
            plumOrPrune.displayClassName();
        }
    }

    /** This is the run() method, which will call the create/display methods
     *  also contained in this class.
     */
    public void run() {
        System.out.println(System.lineSeparator()
                + "PART I: What's in my ArrayList?");
        createPlumPruneFruits();
        displayPlumPruneFruits();

        System.out.println(System.lineSeparator()
                + "PART II: Now that we've got all these "
                + "prunes and plums, let's bake a prune cake!");
        System.out.println();
        processFruit();
    }

    // Part 2: Instantiate the ProcessFruits class and call its methods
    MakeAPruneCake makeAPruneCake = new MakeAPruneCake();

    /** The processFruit method will send the fruit objects in the ArrayList
     *  to the MakeAPruneCake class, determine whether they are prunes or plums,
     *  and call the appropriate method.
     *
     *  @return pruneOrPlum
     */
    public void processFruit() {
        for (Fruit pruneOrPlum : twoFruits) {
            if (pruneOrPlum.getFruitType().equals("plum")) {
                makeAPruneCake.dehydratePlum(pruneOrPlum);
            } else {
                makeAPruneCake.mincePrune(pruneOrPlum);
            }
        }
    }
}
