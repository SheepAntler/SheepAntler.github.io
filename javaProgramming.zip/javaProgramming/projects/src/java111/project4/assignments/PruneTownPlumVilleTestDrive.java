/** This class contains the Main method for the PruneTownPlumVille class.
 *  It will instantiate a PruneTownPlumVille object and call its methods
 *  to start it running.
 */
public class PruneTownPlumVilleTestDrive {
    /** Here is the main method itself!
     *  @param args
     */
    public static void main(String[] args) {
        // instantiate a PruneTownPlumVille object
        PruneTownPlumVille testFruits = new PruneTownPlumVille();

        // call the run method
        testFruits.run();

        // make it look pretty
        System.out.println();
    }
}
