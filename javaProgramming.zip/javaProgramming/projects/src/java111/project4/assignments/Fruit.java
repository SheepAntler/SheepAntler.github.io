/** This class represents a Fruit object. It contains a single method,
 *  which will output the name of this class.
 *
 *  @author Elspeth Stalter-Clouse
 */
public class Fruit {
    // Part 1: display the class
    public void displayClassName() {
        System.out.println(System.lineSeparator() + "Hi! I'm from the fruit "
                + "class!");
    }

    // Part 2: create a type for each fruit
    private String fruitType;

    // get-and-set
    /** get the type of each fruit
     *  @return fruitType
     */
    public String getFruitType() {
        return fruitType;
    }

    /** set the type of each fruit
     *  @param fruitType
     */
    public void setFruitType(String fruitType) {
        this.fruitType = fruitType;
    }
}
