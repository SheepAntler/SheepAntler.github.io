/** This AutoLoan class is a subclass of the BankAccount class. It will
 *  implement the abstract methods in its superclass
 *
 *  @author Elspeth Stalter-Clouse
 */
public class AutoLoan extends BankAccount {

    /** override the creditAccount method
     *  @param creditAmount
     *  @return calculation
     */
    public double creditAccount(double creditAmount) {
        return getBalance() - creditAmount;
    }

    /** override the debitAccount method
     *  @param debitAmount
     *  @return calculation
     */
    public double debitAccount(double debitAmount) {
        return getBalance() + debitAmount;
    }
}
