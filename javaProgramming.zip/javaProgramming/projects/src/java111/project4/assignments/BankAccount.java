/** This class represents an abstract BankAccount object. It will hold
 *  some instance variables and a couple of abstract methods
 *
 *  @author Elspeth Stalter-Clouse
 */
public abstract class BankAccount {
    // variables!
    private double balance;
    private String accountName;
    private double debitAmount;
    private double creditAmount;

    // get-and-set!
    /** get the balance
     *  @return balance
     */
    public double getBalance() {
        return balance;
    }

    /** set the balance
     *  @param Balance
     */
    public void setBalance(double balance) {
        this.balance = balance;
    }

    /** get the accountName
     *  @return accountName
     */
    public String getAccountName() {
        return accountName;
    }

    /** set the accountName
     *  @param accountName
     */
    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    /** get the debitAmount
     *  @return debitAmount
     */
    public double getDebitAmount() {
        return debitAmount;
    }

    /** set the debitAmount
     *  @param debitAmount
     */
    public void setDebitAmount(double debitAmount) {
        this.debitAmount = debitAmount;
    }

    /** get the creditAmount
     *  @return creditAmount
     */
    public double getCreditAmount() {
        return creditAmount;
    }

    /** set the creditAmount
     *  @param creditAmount
     */
    public void setCreditAmount(double creditAmount) {
        this.creditAmount = creditAmount;
    }

    // a couple of abstract methods
    public abstract double debitAccount(double debitAmount);
    public abstract double creditAccount(double creditAmount);
}
