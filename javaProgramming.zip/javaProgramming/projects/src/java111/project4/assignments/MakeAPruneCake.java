/** This class will contain some additional methods to use on Plum and Prune
 *  objects.
 */
public class MakeAPruneCake {
    /** This is the dehydratePlum method which will accept a Fruit object
     *  and call its displayClassName() method
     *
     * @param plumToDehydrate
     */
    public void dehydratePlum(Fruit plumToDehydrate) {
        plumToDehydrate.displayClassName();
        System.out.println("This plum is now a prune.");
    }

    /** This is the mincePrune() method which will accept a Fruit object
     *  and call its displayClassName() method
     *
     *  @param pruneToMince
     */
    public void mincePrune(Fruit pruneToMince) {
        pruneToMince.displayClassName();
        System.out.println("This prune has been minced.");
    }
}
