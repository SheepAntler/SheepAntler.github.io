/** This Abstract class represents a GeneralStudent object. It will
 *  contain instance variables pertaining to objects in GeneralStudent's
 *  subclasses and their get/set methods, plus an abstract method that
 *  will display a progress report for each GeneralStudent object
 *
 *  @author Elspeth Stalter-Clouse
 */
public abstract class GeneralStudent implements TestTaker {
    // instance variables
    private String firstName;
    private String lastName;
    private String school;
    private String grade;
    private String strongestSubject;
    private String weakestSubject;
    private String testCompletionTime;

    // get-and-set!

	/**
	* Returns value of firstName
	* @return firstName
	*/
	public String getFirstName() {
		return firstName;
	}

	/**
	* Sets new value of firstName
	* @param firstName
	*/
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	* Returns value of lastName
	* @return lastName
	*/
	public String getLastName() {
		return lastName;
	}

	/**
	* Sets new value of lastName
	* @param lastName
	*/
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	* Returns value of school
	* @return school
	*/
	public String getSchool() {
		return school;
	}

	/**
	* Sets new value of school
	* @param school
	*/
	public void setSchool(String school) {
		this.school = school;
	}

	/**
	* Returns value of grade
	* @return grade
	*/
	public String getGrade() {
		return grade;
	}

	/**
	* Sets new value of grade
	* @param grade
	*/
	public void setGrade(String grade) {
		this.grade = grade;
	}

	/**
	* Returns value of strongestSubject
	* @return strongestSubject
	*/
	public String getStrongestSubject() {
		return strongestSubject;
	}

	/**
	* Sets new value of strongestSubject
	* @param strongestSubject
	*/
	public void setStrongestSubject(String strongestSubject) {
		this.strongestSubject = strongestSubject;
	}

	/**
	* Returns value of weakestSubject
	* @return weakestSubject
	*/
	public String getWeakestSubject() {
		return weakestSubject;
	}

	/**
	* Sets new value of weakestSubject
	* @param weakestSubject
	*/
	public void setWeakestSubject(String weakestSubject) {
		this.weakestSubject = weakestSubject;
	}

	/**
	* Returns value of testCompletionTime
	* @return testCompletionTime
	*/
	public String getTestCompletionTime() {
		return testCompletionTime;
	}

	/**
	* Sets new value of testCompletionTime
	* @param testCompletionTime
	*/
	public void setTestCompletionTime(String testCompletionTime) {
		this.testCompletionTime = testCompletionTime;
	}

    /** The abstract displayProgress() method will be overridden in the
     *  subclasses to output progress reports for student objects
     *  @return the progressResport string
     */
    public abstract String displayProgress();
}
