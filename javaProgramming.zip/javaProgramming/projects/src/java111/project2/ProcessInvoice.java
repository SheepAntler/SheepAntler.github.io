/** This class will instantiate an Invoice object and instantiate three items into
 *  the items array.
 *
 * @author Elspeth Stalter-Clouse
 */
public class ProcessInvoice {
    // make an instance variable that will hold an invoice object
    // DO NOT instantiate it now; that comes later!
    Invoice invoice;

    /** this private method will instantiate three item objects into the array
     *  (complete with all pertainanent item info) and set the array into the Invoice object
     *   object with the set method.
     */
    private void createItems() {
        Item[] items = new Item[3];

        items[0] = new Item();
        items[0].setItemId(123);
        items[0].setItemQuantity(5);
        items[0].setItemPrice(6.99);
        items[0].setItemDescription("Sprill");

        items[1] = new Item();
        items[1].setItemId(456);
        items[1].setItemQuantity(12);
        items[1].setItemPrice(2.49);
        items[1].setItemDescription("Whatchamacallit");

        items[2] = new Item();
        items[2].setItemId(789);
        items[2].setItemQuantity(8);
        items[2].setItemPrice(4.50);
        items[2].setItemDescription("Floink");

        // set these items into the array with the set method from the Invoice class
        invoice.setItems(items);

    }

    /** this method will instantiate a new Invoice object, put the three new
     *  items in the array for REAL, and call the Invoice methods
     *  on the invoice variable
     */
    public void runProcess() {
        // instantiate a new Invoice object; assign it to the instance variable
        invoice = new Invoice();

        // create the books by calling the appropriate method IN THIS VERY CLASS!
        createItems();

        // call the Invoice methods on the invoice variable
        invoice.calculateInvoice();
        invoice.displayInvoice();

    }

}
