/** This class will create an array to hold item objects and methods to
 *  loop through the array and calculate the total invoice price and print
 *  each item's information to the terminal window.
 *
 * @author Elspeth Stalter-Clouse
 */
public class Invoice {
    // create an empty array to hold Item objects
    // and a double to hold the invoice total
    private Item[] items;
    private double invoiceTotal;

    /** get the Invoice total
     *  @return invoiceTotal
     */
    public double getInvoiceTotal() {
        return invoiceTotal;
    }

    /** set item objects into the empty array for Item objects
     *  @param newItems
     */
    public void setItems(Item[] newItems) {
        items = newItems;
    }

    /** this method which will loop through the item array
     *  and calculate the total price for the invoice
     */
    public void calculateInvoice() {
        // the for loop! King of the Loops!
        for (int counter = 0; counter < items.length; counter++) {
            invoiceTotal += items[counter].calculateItemTotal();
        }
    }

    /** this method will loop through the array and call each item's display
     *  method. It will also output the total price for the invoice.
     */
    public void displayInvoice() {
        // make the output look pretty (or not all bunched up, at least)
        System.out.println();
        // loop through the array and output each item's information
        for (int counter = 0; counter < items.length; counter++) {
            System.out.println(items[counter].display());
        }

        // output total price, too
        System.out.println();
        System.out.println("The grand total for all items on this invoice is: $"
                + String.format("%.2f", getInvoiceTotal()) + ".");
    }

}
