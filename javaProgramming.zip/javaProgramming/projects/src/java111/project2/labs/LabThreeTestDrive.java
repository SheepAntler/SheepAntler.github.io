/** This contains the main method for LabThree in which the sayHello
 *  method will be called and passed a name as an argument
 *
 * @author Elspeth Stalter-Clouse
 */
public class LabThreeTestDrive {
    /** This will call the sayHello method several times
     *  and pass names to it as arguments
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {

        LabThree callMethod = new LabThree();

        System.out.println();
        System.out.println("Here are the sayHello methods...");
        System.out.println();

        callMethod.sayHello("Silly Billy");
        callMethod.sayHello("Foxy Loxy");
        callMethod.sayHello("Calamity Jane");
        callMethod.sayHello("Squirrel Nutkin");

        System.out.println();
        System.out.println("...and HERE is the sayHelloAgain method!");
        System.out.println();

        callMethod.sayHelloAgain("Benjamin Franklin", 5);
    }
}
