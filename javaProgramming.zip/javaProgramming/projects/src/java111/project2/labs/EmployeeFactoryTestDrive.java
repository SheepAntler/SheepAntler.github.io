/** This class contains the main method for the EmployeeFactory class, and
 *  will call its setup method to test import junit.framework.TestCase;
 *
 * @author Elspeth Stalter-Clouse
 */
public class EmployeeFactoryTestDrive {
    /** Instantiate an instance of the EmployeeFactory class
     *  and call its setup, runWhile, and runFor methods.
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {
        // Instsantiate an employee factory and call its setup method
        EmployeeFactory employeeFactoryTest = new EmployeeFactory();

        employeeFactoryTest.setup();
        employeeFactoryTest.runWhile();
        employeeFactoryTest.runFor();
    }
}
