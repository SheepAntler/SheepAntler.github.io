/** This class contains a method that will output the phrase "Hello there "
 *  to the command line, followed by a name passed to it as an argument
 *
 * @author Elspeth Stalter-Clouse
 */

public class LabThree {
    /** This method has one parameter
     *  and will output a message to the command line.
     *
     * @param someName The name to output after the message
     */
    public void sayHello(String someName) {
        System.out.println("Hello there, " + someName + "!");
    }

    /** This method has two parameters--one for a String and one for an int
     *  and it will output a message to the command line several times
     *
     */
    public void sayHelloAgain(String anotherName, int loopCounter) {
        while (loopCounter > 0) {
            System.out.println("Hello there, " + anotherName + ".");
            loopCounter--;
        }
    }
}
