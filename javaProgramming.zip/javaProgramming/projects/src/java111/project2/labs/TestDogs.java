/** This class will instantiate a total of three Dog objects
 *  and assign them to one another/set them to null
 *  in order to practice using the Garbage Collector.
 *
 * @author Elspeth Stalter-Clouse
 */
public class TestDogs {
    /** Instantiate two Dog objects
     * and call their bark methods.
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {
        // Instantiate the first Dog object
        DogLabTwo dog1 = new DogLabTwo();

        dog1.name = "Fido";

        // Instantiate the second Dog object
        DogLabTwo dog2 = new DogLabTwo();

        dog2.name = "Spot";

        dog1.bark();
        dog2.bark();

        System.out.println("");

        // Assign dog1 to dog2
        dog2 = dog1;

        System.out.println("");
        System.out.println("After assigning dog1 to dog2: ");
        System.out.println("");

        dog1.bark();
        dog2.bark();

        // Instantiate a third Dog object
        DogLabTwo dog3 = new DogLabTwo();

        dog3.name = "Lola";

        System.out.println("");
        System.out.println("After adding dog3: ");
        System.out.println("");

        dog1.bark();
        dog2.bark();
        dog3.bark();

        // Set dog3 to 'null'
        dog3 = null;

        System.out.println("");
        System.out.println("After assigning dog1 to dog2 AND assigning null to " +
                "the third dog: ");
        System.out.println("");

        dog1.bark();
        dog2.bark();
        dog3.bark();

    }

}
