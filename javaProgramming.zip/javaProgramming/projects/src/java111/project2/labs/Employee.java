/** This Employee class will contain four private instance variables
 *  plus public get and set methods for each of them. It will also
 *  contain a method to output the instance varibles' values to the command line.
 *
 * @author Elspeth Stalter-Clouse
 */
public class Employee {
    // The private instance variables
    private String firstName;
    private String lastName;
    private int employeeId;
    private double employeeSalary;

    // Public set methods for each variable
    /** Set the firstName
     *  @param newFirstName
     */
    public void setFirstName(String newFirstName) {
        firstName = newFirstName;
    }

    /** Set the lastName
     *  @param newLastName
     */
    public void setLastName(String newLastName) {
        lastName = newLastName;
    }

    /** Set the employeeId
     *  @param newEmployeeId
     */
    public void setEmployeeId(int newEmployeeId) {
        employeeId = newEmployeeId;
    }

    /** Set the employeeSalary
     *  @param newEmployeeSalary
     */
    public void setEmployeeSalary(double newEmployeeSalary) {
        employeeSalary = newEmployeeSalary;
    }

    //Public get methods for each variable
    /** Get the firstName
     *  @return firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /** Get the lastName
     *  @return lastName
     */
    public String getLastName() {
        return lastName;
    }

    /** Get the employeeId
     *  @return employeeId
     */
    public int getEmployeeId() {
        return employeeId;
    }

    /** Get the employeeSalary
     *  @return employeeSalary
     */
    public double returnSalary() {
        return employeeSalary;
    }

    /** This method uses the get methods above to output the values
     *  of all the instance variables.
     *
     */
    public void display() {
        System.out.println(firstName + " " + lastName
                + " has employee id number " + employeeId + ", and earns $"
                + String.format("%,.2f", employeeSalary) + " each year.");
    }
}
