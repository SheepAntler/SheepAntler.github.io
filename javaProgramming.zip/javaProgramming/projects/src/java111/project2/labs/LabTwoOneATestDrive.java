/** This class will hold the main method which will test the
 *  LabTwoOneA methods.
 *
 * @author Elspeth Stalter-Clouse
 */
public class LabTwoOneATestDrive {
    /** Instantiate a LabTwoOneA object and
     *  run the methods on it.
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {

        // Instantiate a LabTwoOneA object
        LabTwoOneA doSomeMath = new LabTwoOneA();

        // Run the two methods on doSomeMath
        doSomeMath.calculateProduct();
        doSomeMath.calculateQuotient();
    }
}
