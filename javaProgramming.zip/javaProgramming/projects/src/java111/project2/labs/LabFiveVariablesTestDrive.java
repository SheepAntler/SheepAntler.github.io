/** The main method for LabFiveVariables. This class will instantiate an
 *  instance of the LaBFiveVariables class and call its run method.
 *
 * @author Elspeth Stalter-Clouse
 */
public class LabFiveVariablesTestDrive {
    /** make the main method
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {
        // instantiate an instance of the LabFiveVariables class
        LabFiveVariables labFiveVariablesTest = new LabFiveVariables();

        labFiveVariablesTest.run();

        System.out.println("The instance variable named count is: " +
                labFiveVariablesTest.getCount() + " (printed from the main() method).");
    }
}
