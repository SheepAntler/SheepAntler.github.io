/** This class will contain the run method for this lab which will
 *  declare four initialized local varibles plus two results variables, then
 *  perform some basic math with the numbers in the variables and output the
 *  results to the terminal.
 *
 * @author Elspeth Stalter-Clouse
 */
public class FunWithNumbers {
    /** Here is the run method for this class, which will
     *  perform all of the tasks listed above.
     *
     * @param args command line arguments
     */
    public void run() {
        // Variable declaration
        int firstNumber = 5;
        int secondNumber = 10;
        int thirdNumber = 3;
        int fourthNumber = 25;
        int integerResults = 0;
        double doubleResults = 0.0;

        integerResults = firstNumber + secondNumber + thirdNumber + fourthNumber;

        doubleResults = (firstNumber * secondNumber * fourthNumber) / thirdNumber;

        System.out.println(System.lineSeparator() + firstNumber + " + "
                + secondNumber + " + " + " + " + thirdNumber + " + "
                + fourthNumber + " = " + integerResults);

        System.out.println("(" + firstNumber + " * "
                + secondNumber + " * " + fourthNumber + ") / " + thirdNumber
                + " = " + String.format("%.0f", doubleResults));
    }
}
