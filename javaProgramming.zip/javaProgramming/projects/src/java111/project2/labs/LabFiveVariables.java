/** This class contains a private int variable, and a run method which contains
 *  a local variable and outputs both variables to the command line.
 *
 * @author Elspeth Stalter-Clouse
 */
public class LabFiveVariables {
    // private instance variable
    private int count = 1;

    // Set-and-get!
    /** set the count variable
     *  @param newCount
     */
    public void setCount(int newCount) {
        count = newCount;
    }

    /** get the count variable
     * @return count
     */
    public int getCount() {
        return count;
    }

    /** The run method which will contain a local variable and which will
     *  output 3 lines of text to the command line
     *
     * @param args command line arguments
     */
    public void run() {
        // local variables
        int count = 15;

        System.out.println(System.lineSeparator() + "The local variable named "
                + "count is: " + count);

        // First way to output the instance variable count: get only
        System.out.println("The instance variable named count is: " + getCount() +
                " (printed from the run() method)");

        //Second way to output the instance variable count: set & get
        setCount(1);
        System.out.println("The instance variable named count is: " +
                getCount() + " (printed from the run() method)");

    }
}
