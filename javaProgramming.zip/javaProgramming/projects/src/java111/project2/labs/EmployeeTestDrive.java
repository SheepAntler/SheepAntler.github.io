/** This Employee Test Drive class will instantiate three objects of the Employee
 *  class and assign data to their instance variables. Their display methods
 *  will be called here to output the data to the command line.
 *
 *  @author Elspeth Stalter-Clouse
 */
public class EmployeeTestDrive {
    /** This is the main method for this class
     *
     * @param args Command Line Arguments
     */
    public static void main(String[] args) {

        Employee employee1 = new Employee();
        // Set the data for employee1
        employee1.setFirstName("Queenie");
        employee1.setLastName("Constantini");
        employee1.setEmployeeId(345);
        employee1.setEmployeeSalary(54000.00);

        Employee employee2 = new Employee();
        // Set the data for employee2
        employee2.setFirstName("Pinocchio");
        employee2.setLastName("Puppetface");
        employee2.setEmployeeId(789);
        employee2.setEmployeeSalary(89950.64);

        Employee employee3 = new Employee();
        // Set the data for employee1
        employee3.setFirstName("Moneybags");
        employee3.setLastName("von WealthPants");
        employee3.setEmployeeId(007);
        employee3.setEmployeeSalary(1250000.00);

        // Call the employee's display methods
        System.out.println();
        employee1.display();
        employee2.display();
        employee3.display();
    }
}
