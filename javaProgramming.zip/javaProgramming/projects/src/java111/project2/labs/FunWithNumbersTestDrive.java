/** This contains the main method for the FunWithNumbers lab. It will
 *  instantiate an object of type FunWithNumbers and call its run method.
 *
 * @author Elspeth Stalter-Clouse
 */
public class FunWithNumbersTestDrive {
    /** Instantiate an object of the FunWithNumbers class
     *  and call its run method.
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {

        FunWithNumbers funWithNumbersTestRun = new FunWithNumbers();

        funWithNumbersTestRun.run();
    }
}
