/**
 *  The Dog class which we will use in lab 2
 *
 * @author    Elspeth Stalter-Clouse
 */
public class DogLabTwo {

    String  name;

    /**
     *  This method is the code for the bark action
     */
    void bark() {
        System.out.println("My name is " + name  + ", Ruff!");
    }
}
