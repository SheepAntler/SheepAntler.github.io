/** This class contains an empty instance variable array to contain references
 *  to Employees. It also has a setup method that will instantiate a new
 *  Employee array that holds 3 employees and two loops (while and for) which will
 *  loop through the array and output the data in it to the command line.
 *
 *  @author Elspeth Stalter-Clouse
 */

public class EmployeeFactory {
    // Create an empty instance variable array
    Employee[] listOfEmployees;

    /** This is the setup method which will instantiate the employee array
     *  and populate it with three employees' data
     */
    public void setup() {
        // instantiate an array to hold 3 employee object references
        listOfEmployees = new Employee[3];

        // create 3 employee objects and set their names and quantities
        listOfEmployees[0] = new Employee();
        listOfEmployees[0].setFirstName("Jazz");
        listOfEmployees[0].setLastName("Hands");
        listOfEmployees[0].setEmployeeId(8);
        listOfEmployees[0].setEmployeeSalary(98000.00);

        listOfEmployees[1] = new Employee();
        listOfEmployees[1].setFirstName("Boaty");
        listOfEmployees[1].setLastName("McBoatFace");
        listOfEmployees[1].setEmployeeId(1055);
        listOfEmployees[1].setEmployeeSalary(74000.00);

        listOfEmployees[2] = new Employee();
        listOfEmployees[2].setFirstName("Scooby");
        listOfEmployees[2].setLastName("Doo");
        listOfEmployees[2].setEmployeeId(25);
        listOfEmployees[2].setEmployeeSalary(49000.00);
    }

    /** This is the runWhile method which will output the employee data
     *  using a while loop
     */
    public void runWhile() {
        // create a counter instance variable
        int counter = 0;
        // make it look pretty
        System.out.println();
        System.out.println("Displaying employees using a while loop:");
        System.out.println();

        while (counter < listOfEmployees.length) {
            listOfEmployees[counter].display();
            counter++;
        }
    }

    /** This is the runFor method which will output the employee data
     *  using a for loop
     */
    public void runFor() {
        // make it look pretty
        System.out.println();
        System.out.println("Displaying employees using a for loop:");
        System.out.println();

        for (int counter = 0; counter < listOfEmployees.length; counter++) {
            listOfEmployees[counter].display();
        }
    }
}
