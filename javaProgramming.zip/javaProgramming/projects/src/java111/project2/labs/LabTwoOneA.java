/** A class designed to hold some primitive variables.
 *
 * @author Elspeth Stalter-Clouse
 */
public class LabTwoOneA {
    // Instance variables
    int myInt = 5;
    long myLong = 78;
    double myDouble = 2.7;

    // The method that will calculate the product of all the variables
    public void calculateProduct() {
        System.out.println(myInt + " * " + myLong + " * " + myDouble + " = " +
                (myInt * myLong * myDouble) + " This is the expected answer.");
    }

    // The method that will calculate the quotient of myLong and myInt
    public void calculateQuotient() {
        System.out.println(myLong + " / " + myInt + " = " + (myLong/myInt) +
                " This is not the expected answer.");
    }
}
