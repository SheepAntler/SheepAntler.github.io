/** This class contains an array to hold student objects, a method
 *  to instantiate it and populate it with student objects, and a method
 *  to loop through the student array and call the display method to output the
 *  student information to the command line.
 *
 * @author Elspeth Stalter-Clouse
 */
public class ProcessStudents {
    //create an array to hold student objects
    private Student[] students;

    /** This method calls the createStudents() method
     *  and the displayStudents() method IN THAT ORDER!
     */
    public void runStudentProcessing() {

        createStudents();
        displayStudents();
    }

    /** The createStudents() method which will create the student array
     *  declared above and instantiate three student objects within import junit.framework.TestCase;
     */
    public void createStudents() {
        // create/assign an array of three student objects
        students = new Student[3];

        // instantiate three student objects--one default and two custom
        students[0] = new Student();
        students[0].setStudentName("Judy Jetson");
        //Do I need to do this?
        //students[0].getStudentId();
        //students[0].getTotalCreditHours();
        //students[0].getTotalGradePoints();

        students[1] = new Student();
        students[1].setStudentName("Smorg S. Board");
        students[1].setStudentId(4561234);
        students[1].setTotalCreditHours(34);
        students[1].setTotalGradePoints(110);

        students[2] = new Student();
        students[2].setStudentName("Scritti Politti");
        students[2].setStudentId(7723324);
        students[2].setTotalCreditHours(32);
        students[2].setTotalGradePoints(128);
    }

    /** loop through the array of Students
     *  and call the display method on each of them
     */
    public void displayStudents() {
        // use a for loop; the superior loop for all your looping needs
        for (int counter = 0; counter < students.length; counter++) {
            students[counter].displayStudentInfo();
        }
    }
}
