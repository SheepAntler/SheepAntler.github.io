/** This is a class containing some primitive data types
 *  and a loop which will do a bit of math and output the answer.
 *
 * @author Elspeth Stalter-Clouse
 */
public class AssignmentOne {
    // Instance variables
    int loopCounter = 10;
    double additionValue = 12.76;
    double calculatedTotal;

    // The method containing a while loop
    public void calculateTotal() {

        calculatedTotal = 0;

        while (loopCounter > 0) {
            calculatedTotal = calculatedTotal + additionValue;
            loopCounter = loopCounter - 1;
        }

        System.out.println("Adding 12.76 to itself 10 times results in: " +
                calculatedTotal);
    }
}
