/** This class will create an instance of FruitCounter and get it to run
 *
 *  @author Elspeth Stalter-Clouse
 */
public class FruitCounterTestDrive {
    /** Instantiate 6 fruit objects and add their quantities
     *  into the fruitTotal int variable
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {
        // Instantiate a FruitCounter and call its run method
        FruitCounter fruitCounterTest = new FruitCounter();

        System.out.println();
        fruitCounterTest.run();
    }
}
