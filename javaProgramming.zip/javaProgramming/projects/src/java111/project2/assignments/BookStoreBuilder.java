/** This class creates a bookstore and then fills it with books.
 *  It will be used to emphasize
 *  Unit 2 concepts and help you prepare
 *  for Project 2.
 *  @author Elspeth Stalter-Clouse
 */

public class BookStoreBuilder {
    // instance variable to hold a BookStore object,
    BookStore bookStore;

    /** This is the buildBookInventory method which will instantiate several
     *  book objects, place them into a local array, and then set the local
     *  array into the BookStore's booksInventory array with the set method.
     */
    public void buildBookInventory() {
        Book[] books = new Book[8];

        books[0] = new Book();
        books[0].setTitle("Strong Female Protagonist");
        books[0].setAuthor("Brennan Lee Mulligan and Molly Ostertag");
        books[0].setPublicationYear(2015);
        books[0].setNumberOfCopies(3);
        books[0].setSize(1.5);

        books[1] = new Book();
        books[1].setTitle("Calypso");
        books[1].setAuthor("David Sedaris");
        books[1].setPublicationYear(2018);
        books[1].setNumberOfCopies(5);
        books[1].setSize(1.7);

        books[2] = new Book();
        books[2].setTitle("Vanity Fair");
        books[2].setAuthor("William Makepeace Thackeray");
        books[2].setPublicationYear(1848);
        books[2].setNumberOfCopies(2);
        books[2].setSize(5.8);

        books[3] = new Book();
        books[3].setTitle("The Ultimate Hitchhiker's Guide to the Galaxy");
        books[3].setAuthor("Douglas Adams");
        books[3].setPublicationYear(1996);
        books[3].setNumberOfCopies(4);
        books[3].setSize(6);

        books[4] = new Book();
        books[4].setTitle("Pride and Prejudice and Zombies");
        books[4].setAuthor("Seth Grahame-Smith and Jane Austen");
        books[4].setPublicationYear(2009);
        books[4].setNumberOfCopies(6);
        books[4].setSize(2.2);

        books[5] = new Book();
        books[5].setTitle("The Essex Serpent");
        books[5].setAuthor("Sarah Perry");
        books[5].setPublicationYear(2016);
        books[5].setNumberOfCopies(4);
        books[5].setSize(3.2);

        books[6] = new Book();
        books[6].setTitle("The Cookbook Collector");
        books[6].setAuthor("Allegra Goodman");
        books[6].setPublicationYear(2010);
        books[6].setNumberOfCopies(1);
        books[6].setSize(3.4);

        books[7] = new Book();
        books[7].setTitle("The Inheritance Trilogy");
        books[7].setAuthor("N.K. Jemisin");
        books[7].setPublicationYear(2011);
        books[7].setNumberOfCopies(5);
        books[7].setSize(6.2);

        // Set this array into the BookStore array using the set method.
        bookStore.setBooksInventory(books);
    }

     /** The run method, which will instantiate a new BookStore object,
      *  call the buildBookInventory method to create books, and then calls
      *  the BookStore method to display the book info, which will trigger
      *  the calculateTotalWidth method as well.
      */
    public void run() {
        // Instantiate a new BookStore object and assign it to the instance
        // variable
        /** Note for myself for later: DO NOT put down BookStore as your type
         *  (e.g. BookStore bookStore = new BookStore())
         *  BECAUSE if you DO you'll create a new, local reference to the variable with
         *  the same name as you've got up above and that you'll end up with
         *  a null pointer exception. Ruh-roh!
         */
        bookStore = new BookStore();

        // Call the method to create the books
        buildBookInventory();

        // Call the display method in the BookStore to calculate the total book distance
        // AND calculate the total book distance
        bookStore.displayBookInventory();

    }
}
