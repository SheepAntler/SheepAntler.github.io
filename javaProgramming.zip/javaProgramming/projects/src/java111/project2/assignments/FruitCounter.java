/** This class will create an instance variable array to hold fruit objects,
 *  an instance variable int that will add all the fruit quantities, and
 *  a run method that will create fruit objects, put them in the array, get
 *  and set their names/quantities, and add them all together. Whew!
 *
 * @author Elspeth Stalter-Clouse
 */
public class FruitCounter {
    // Create an instance variable to hold an array of fruits
    Fruit[] listOfFruits;
    // Create an instance variable that will hold the total fruit quantity
    int fruitTotal;

    /** a method to create fruit objects and place them into the array
     *  instance variable
     */
    public void run() {
        //instantiate an array to hold fruit object references
        listOfFruits = new Fruit[6];

        // create six fruits and set their names and quantities
        listOfFruits[0] = new Fruit();
        listOfFruits[0].setFruitName("starfruits");
        listOfFruits[0].setFruitQuantity(5);

        listOfFruits[1] = new Fruit();
        listOfFruits[1].setFruitName("boysenberries");
        listOfFruits[1].setFruitQuantity(24);

        listOfFruits[2] = new Fruit();
        listOfFruits[2].setFruitName("gooseberries");
        listOfFruits[2].setFruitQuantity(12);

        listOfFruits[3] = new Fruit();
        listOfFruits[3].setFruitName("jackfruit");
        listOfFruits[3].setFruitQuantity(1);

        listOfFruits[4] = new Fruit();
        listOfFruits[4].setFruitName("watermelons");
        listOfFruits[4].setFruitQuantity(2);

        listOfFruits[5] = new Fruit();
        listOfFruits[5].setFruitName("nectarines");
        listOfFruits[5].setFruitQuantity(7);

        /** loop through the array and add all of the fruit quantities
         *  into the fruitTotal instance variable
         */
        for (int counter = 0; counter < listOfFruits.length; counter++) {
            listOfFruits[counter].outputFruitData();
            fruitTotal += listOfFruits[counter].getFruitQuantity();
        }

        System.out.println();
        System.out.println("Total pieces of fruit: " + fruitTotal);
    }
}
