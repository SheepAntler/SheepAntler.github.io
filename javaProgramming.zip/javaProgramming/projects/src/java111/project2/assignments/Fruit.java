/** This class will hold two private instance variables
 *  and their get/set methods.
 *
 * @author Elspeth Stalter-Clouse
 */
public class Fruit {
    // Private instance variables
    private String fruitName;
    private int fruitQuantity;

    /** set fruitName
     *  @param newFruitName
     */
    public void setFruitName(String newFruitName) {
        fruitName = newFruitName;
    }

    /** set fruitQuantity
     *  @param newFruitQuantity
     */
    public void setFruitQuantity(int newFruitQuantity) {
        fruitQuantity = newFruitQuantity;
    }

    /** get fruitName
     *  @return fruitName
     */
    public String getFruitName() {
        return fruitName;
    }

    /** get fruitQuantity
     *  @return fruitQuantity
     */
    public int getFruitQuantity() {
        return fruitQuantity;
    }

    // This method will output a string about each fruit in the array
    // to the command line
    public void outputFruitData() {
        System.out.println("I have " + fruitQuantity + " " + fruitName + ".");
    }

}
