/** Represents a book.
 *  Used emphasize Unit 2 concepts and help you prepare
 *  for Project 2.
 *  @author Elspeth Stalter-Clouse
 */
public class Book {

    // private instance variables for title, author, publicationYear,
    // numberOfCopies, and size (book width in cm)
    private String title;
    private String author;
    private int publicationYear;
    private int numberOfCopies;
    private double size;

    // public getters and setters for each instance variable

    /** set the book's title
     *  @param newTitle
     */
    public void setTitle(String newTitle) {
        title = newTitle;
    }

    /** get the book's title
     *  @return title
     */
    public String getTitle() {
        return title;
    }

    /** set the book's author
     *  @param newAuthor
     */
    public void setAuthor(String newAuthor) {
        author = newAuthor;
    }

    /** get the book's author
     *  @return author
     */
    public String getAuthor() {
        return author;
    }

    /** set the publicationYear of the book
     *  @param newPublicationYear
     */
    public void setPublicationYear(int newPublicationYear) {
        publicationYear = newPublicationYear;
    }

    /** get the publicationYear of the book
     *  @return publicationYear
     */
    public int getPublicationYear() {
        return publicationYear;
    }

    /** set the numberOfCopies for the book
     *  @param newNumberOfCopies
     */
    public void setNumberOfCopies(int newNumberOfCopies) {
        numberOfCopies = newNumberOfCopies;
    }

    /** get the numberOfCopies for the book
     *  @return numberOfCopies
     */
    public int getNumberOfCopies() {
        return numberOfCopies;
    }

    /** set the book's size
     *  @param newSize
     */
    public void setSize(double newSize) {
        size = newSize;
    }

    /** get the book's size
     *  @return size
     */
    public double getSize() {
        return size;
    }

    /** This method will calculate the width all my books will need
     *  on the shelves.
     *  @return total calculated book width
     */
    public double calculateWidth() {
        // Multiply numberOfCopies by size
        return numberOfCopies * size;
    }

    /** This method will output the information for each book to the terminal
     * window.
     * @return book title, author, publicationYear, numberOfCopies, and size
     */
    public String displayBookInformation() {
        String bookInformation = "We have " + numberOfCopies + " copy/copies "
            + " of the " + publicationYear + " book " + title + " by " + author
            + ". Each copy of " + title + " is " + size + " cm wide, which "
            + "amounts to a total of " + String.format("%.2f", calculateWidth())
            + " cm all told.";

        return bookInformation;
    }
}
