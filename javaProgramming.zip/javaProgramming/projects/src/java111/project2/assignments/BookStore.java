/** This class represents a bookstore.
 *  It will be used to emphasize
 *  Unit 2 concepts and help you prepare
 *  for Project 2.
 *
 *  @author Elspeth Stalter-Clouse
 */

public class BookStore {

    //Create an empty array that will hold book objects
    Book[] booksInventory;

    /** Here is a set method to get books into the array
     *  @param newBooksInventory books that go into the array
     */
    public void setBooksInventory(Book[] newBooksInventory) {
        booksInventory = newBooksInventory;
    }

    /** Loop through the booksInventory array and calculate/return the distance
     *  the books will need on the shelf.
     * @return totalWidth -- how much space all the books will take up
     */
    public double calculateTotalWidth() {
        // local variable to house the total width
        double totalWidth = 0;
        // for loop!
        for (int counter = 0; counter < booksInventory.length; counter++) {
            totalWidth = totalWidth + booksInventory[counter].calculateWidth();
        }
        // Send the calculated result back!
        return totalWidth;
    }

    /** Create a method that prints out our book store's information by
     *  looping through the booksInventory array and calling the
     *  displayBookInformation() method on each book and prints the total
     *  width of all the books to the terminal window.
     */
    public void displayBookInventory() {
        // Loop through the booksInventory array and display the information
        // by calling the display method from the Book class
        for (int counter = 0; counter < booksInventory.length; counter++) {
            System.out.println(System.lineSeparator()
            + booksInventory[counter].displayBookInformation());
        }
        // Output the total width of all the books to the terminal window
        System.out.println(System.lineSeparator() + "Altogether, the books we have "
                + "will require " + String.format("%.2f", calculateTotalWidth())
                + " cm of shelf space.");
    }
}
