/** Creates an AssignmentOne object and tests import junit.framework.TestCase;
 *  by calling its calculateTotal method and printing it to the page.
 *
 * @author Elspeth Stalter-Clouse
 */
public class AssignmentOneTestDrive {

    /** Instantiate an AssignmentOne object
     *  and call its calculateTotal method.
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {
        // Create an AssignmentOne object
        AssignmentOne assignmentOneMath = new AssignmentOne();

        // Call its calculateTotal method
        assignmentOneMath.calculateTotal();
    }
}
