/** This is the main method for the Item/Invoice/ProcessInvoice classes.
 *  It will instantiate a ProcessInvoice object and call its runProcess method.
 *
 * @author Elspeth Stalter-Clouse
 */
public class InvoiceTestDrive {
    /** Here is the main method itself!
     *  @param args command line arguments
     */
    public static void main(String[] args) {
        //create a ProcessInvoice object
        ProcessInvoice testProcessInvoice  = new ProcessInvoice();

        // call the runProcess() method on the object
        testProcessInvoice.runProcess();
    }
}
