/** This is the main method to test the Student/ProcessStudent classes.
 *  which will instantiate a ProcessStudent object and call its
 *  runStudentProcessing method.
 *
 * @author Elspeth Stalter-Clouse
 */
public class StudentTestDrive {
    /** here it is, folks: THE MAAAAIIIINN METHOOOD!
     *
     *  @param args command line arguments
     */
    public static void main(String[] args) {
        // instantiate a ProcessStudents object
        ProcessStudents testProcessStudents = new ProcessStudents();
        // call the runStudentProcessing() method
        testProcessStudents.runStudentProcessing();
    }
}
