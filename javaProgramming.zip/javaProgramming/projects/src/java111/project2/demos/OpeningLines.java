/** Demo for object references using literature
 *  @author kkohler
 */
public class OpeningLines {

    String title;
    String openingLines;
    int yearPublished;
    String author;

    public void reciteLines() {
        System.out.print(openingLines);
    }
}
