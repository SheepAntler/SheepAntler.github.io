/** This class demonstrates working with an array of object references
 *  as prep for lab 5
 *
 * @author Elspeth Stalter-Clouse
 */
public class VehicleFactory {
    // create an instance variable that will hold an array of vehicle references
    // but do not instantiate the array yet
    Vehicle[] listOfVehicles;

    /** This method will create vehicles and put them in a list **/
    public void createVehicles() {
        // Debugging line
        System.out.println("beginning of createVehicles");
        
        // instantiate an array that will hold vehicle object references
        listOfVehicles = new Vehicle[3];

        // create a vehicle and assign it to the first slot in the array
        listOfVehicles[0] = new Vehicle();

        // use set methods to assign values
        listOfVehicles[0].setMake("Toyota");
        listOfVehicles[0].setModel("Corolla");
        listOfVehicles[0].setYear(2013);
        listOfVehicles[0].setColor("blue");

        // Debugging line
        System.out.println("in the createVehicles");
    }

    /** this method starts each vehicle in the list **/
    public void startAllVehicles() {
        // loop through all the vehicles and call the start method on each one
        // The following line is for debugging
        System.out.println("at the end of startAllVehicles");
    }

    /** this method calls all the other methods **/
    public void run() {
        createVehicles();
        startAllVehicles();
    }
}
