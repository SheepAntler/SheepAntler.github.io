/**
 *  This won't work! Why?
 *
 *@author    eknapp
 */
public class Foo {

    /**
     *  Declaring local variables
     */
    public void go() {
        int  aNumber = 2;
        int  anotherNumber = aNumber + 3;
    }
}
