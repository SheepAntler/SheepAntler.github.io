/**
 *  This class runs the local vs. instance variable demo.
 *
 */
public class LocalVsInstanceVariablesLauncher {
    
    public static void main (String [] args) {
        LocalVsInstanceVariables demo = new LocalVsInstanceVariables();
        demo.run();
    }
}
