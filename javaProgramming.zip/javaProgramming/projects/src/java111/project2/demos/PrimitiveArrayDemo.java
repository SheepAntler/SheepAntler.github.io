/** Demonstrate creating an array that will hold primitive values
 *
 * @author Elspeth Stalter-Clouse
 */
public class PrimitiveArrayDemo {
    /** Create an array to hold 5 doubles
     *  Add doubles to the array
     *  Display each item in the array
     *
     *  @param args command line arguments
     */
     public static void main(String[] args) {
         // Create an array to hold 5 doubles
         double[] prices = new double[5];

         // Add prices to the array
         prices[0] = .99;
         prices[1] = 1.99;
         prices[2] = 9.99;
         prices[3] = 19.99;
         prices[4] = 5.99;

         // Display each item in the array--for loop is the best way
         System.out.println();
         System.out.println("The prices listed using a for loop.");

         for (int counter = 0; counter < prices.length; counter++) {
             System.out.println("The price at index " + counter + " is: $" + prices[counter]);
         }
     }
}
