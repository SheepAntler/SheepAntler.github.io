/** This class will contain the variables (with their get and set methods)
 *  associated with the Student object. It will also contain a method
 *  that calculates a student's GPA and a display method to output the
 *  information for each student.
 *
 * @author Elspeth Stalter-Clouse
 */

/** Note to self: This is for the DecimalFormat code I tried out in
 *  displayStudentInfo for fun. I decided to keep it
 *  even after String.format() worked because
 *  I'd like to have record of it somewhere for the future!
 */
import java.text.DecimalFormat;

public class Student {
    // create private variables
    private String studentName;
    private int studentId = 9999999;
    private int totalCreditHours = 36;
    private int totalGradePoints = 100;

    // Set-and-Get!
    /** set the student's name
     *  @param newStudentName
     */
    public void setStudentName(String newStudentName) {
        studentName = newStudentName;
    }

    /** get the student's name
     *  @return studentName
     */
    public String getStudentName() {
        return studentName;
    }

    /** set the studentId
     *  @param newStudentId
     */
    public void setStudentId(int newStudentId) {
        studentId = newStudentId;
    }

    /** get the studentId
     *  @return studentId
     */
    public int getStudentId() {
        return studentId;
    }

    /** set the totalCreditHours
     *  @param newTotalCreditHours
     */
    public void setTotalCreditHours(int newTotalCreditHours) {
        totalCreditHours = newTotalCreditHours;
    }

    /** get the totalCreditHours
     *  @return totalCreditHours
     */
    public int getTotalCreditHours() {
        return totalCreditHours;
    }

    /** set the totalGradePoints
     *  @param newTotalGradePoints
     */
    public void setTotalGradePoints(int newTotalGradePoints) {
        totalGradePoints = newTotalGradePoints;
    }

    /** get the totalGradePoints
     *  @return totalGradePoints
     */
    public int getTotalGradePoints() {
        return totalGradePoints;
    }

    /** This method calculates and returns the GPA for a student
     *  @return student's GPA
     */
    public double calculateGradePointAverage() {
        // divide grade points by credit hours
        return (double) totalGradePoints / totalCreditHours;
    }

    /** A display method that displays all instance variables
     *  and the calculated gpa.
     */
    public void displayStudentInfo() {
        // Prepare the DecimalFormat to be used on the GPA
        DecimalFormat decimalFormat = new DecimalFormat("0.0");

        System.out.println();
        System.out.println("Student Name: " + studentName);
        System.out.println("Student Id Number: " + studentId);
        System.out.println("Total Credit Hours: " + totalCreditHours);
        System.out.println("Total Grade Points: " + totalGradePoints);
        System.out.println("GPA: " + decimalFormat.format(calculateGradePointAverage()));
    }
}
