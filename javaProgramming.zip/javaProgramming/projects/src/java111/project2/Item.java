/** This class represents an Item. It will contain the instance variables
 *  associated with an item object, their get and set methods, plus a method to
 *  do some calculations and another method to display some information.
 *
 * @author Elspeth Stalter-Clouse
 */
public class Item {
    // create the private instance variables
    private int itemId;
    private int itemQuantity;
    private double itemPrice;
    private String itemDescription;

    // Set-and-get!
    /** set the item's ID
     *  @param newItemId
     */
    public void setItemId(int newItemId) {
        itemId = newItemId;
    }

    /** get the item's ID
     *  @return itemId
     */
    public int getItemId() {
        return itemId;
    }

    /** set the item's quantity
     *  @param newItemQuantity
     */
    public void setItemQuantity(int newItemQuantity) {
        itemQuantity = newItemQuantity;
    }

    /** get the item's quantity
     *  @return itemQuantity
     */
    public int getItemQuantity() {
        return itemQuantity;
    }

    /** set the item's price
     *  @param newItemPrice
     */
    public void setItemPrice(double newItemPrice) {
        itemPrice = newItemPrice;
    }

    /** get the item's price
     *  @return itemPrice
     */
    public double getItemPrice() {
        return itemPrice;
    }

    /** set the item's description
     *  @param newItemDescription
     */
    public void setItemDescription(String newItemDescription) {
        itemDescription = newItemDescription;
    }

    /** get the item's description
     *  @return itemDescription
     */
    public String getItemDescription() {
        return itemDescription;
    }

    /** This method will calculate the item total.
     *  @return item total price
     */
    public double calculateItemTotal() {
        return itemQuantity * itemPrice;
    }

    /** This method will return a String containing information about a
     *  given item object.
     *  @return item description
     */
    public String display() {
        String itemInformation = itemQuantity + " " + itemDescription + "s ("
                + "item ID " + itemId + ") priced at $"
                + String.format("%.2f", itemPrice) + " each will "
                + "cost a total of $"
                + String.format("%.2f", calculateItemTotal()) + ".";

        return itemInformation;
    }
}
