/** This is the main method for Lab36UserInput. It will create a new instance
 *  of that class and call its run method to test it.
 *
 *  @author Elspeth Stalter-Clouse
 */
public class Lab36UserInputTestDrive {
    /** Here is the main method!
     *
     *  @param args
     */
    public static void main(String[] args) {
        // instantiate a Lab36UserInput object
        Lab36UserInput lab6Test = new Lab36UserInput();

        // call the run method
        lab6Test.run();
    }
}
