/**
 *  Assignment 2 Debug exercise. What is wrong with this code?
 *
 *@author    eknapp
 */
public class Assignment2Debug {

    String  firstName = "Fred";
    String  lastName  = "Flintstone";


    /**
     *  Output the full name
     */
    public void fullName() {
        System.out.println("Here is the full name: " + firstName + " " + lastName);
    }

}
