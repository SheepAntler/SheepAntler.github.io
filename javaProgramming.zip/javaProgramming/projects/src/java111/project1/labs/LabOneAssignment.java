/**
 * This class will help me practice assignment in java
 *
 * @author Elspeth Stalter-Clouse
 */
public class LabOneAssignment {
    /**
     * This is the main method for this class which
     * will display a number and a name.
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {
        int myNumber = 25;
        String myNameString = "Fred";

        System.out.println("My favorite number is " + myNumber);
        System.out.println("Mr. Flintstone's first name is " + myNameString);
    }
}
