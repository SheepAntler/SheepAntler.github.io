// package statement
package java111.project5;

/**
 * This is the first class in the first lab of the first semester of Java!
 *
 * @author eknapp
 *
 */
public class LabOneFirstClass {

    /**
     * This is the main method for this class which will
     * output a welcome message.
     *
     * @param args
     */
    public static void main(String[] args) {

        System.out.println("Fee Fi Fo Fum!");
    }
}
