package java111.project5.labs;

/**
 *  Lab 5-1 with multiple classes
 *
 *@author    eknapp
 */
public class Lab51TestDrive {

    /**
     *  The main program for the Lab51TestDrive class
     *
     *@param  args  The command line arguments
     */
    public static void main(String[] args) {

        Lab51 lab = new Lab51();
        
        lab.run();
        
    }
}